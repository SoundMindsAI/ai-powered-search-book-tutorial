---
name: impl-plan-gen
pipeline-stage: 2
pipeline-role: feature_spec.md → implementation_plan.md
description: "Generate, review, or patch implementation plans from feature specs. Use when: creating implementation plans from approved specs, reviewing existing plans for accuracy, auditing plan-spec-codebase alignment, or patching plan inaccuracies. Trigger phrases: create implementation plan, review implementation plan, plan accuracy audit, plan-spec alignment, generate impl plan."
argument-hint: "[path(s): feature_spec.md for Generate, impl_plan.md for Review/Review & Patch, or 'feature_spec.md impl_plan.md' for Reconcile]"
allowed-tools: Read, Glob, Grep, Bash, Write, Edit, Agent
user-invocable: true
---

# Implementation Plan Generator & Reviewer

You are working with implementation plans. Depending on the mode, you either generate a new plan from an approved feature spec, review an existing plan for accuracy, or reconcile a plan against its spec and the codebase.

> Read `PROJECT_CONFIG.md` at the repo root before starting. Every `<placeholder>` resolves from there.

The implementation plan is the bridge between "what to build" (the spec) and "how to build it" (the code). Every claim in the plan must be grounded in both the spec and the codebase.

## Mode selection

| Mode | When to use | Writing behavior |
|---|---|---|
| **Generate** | User provides a path to an approved feature spec. No implementation plan exists yet. | Creates a new plan file. |
| **Review** | User provides a path to an existing plan. Asks for accuracy review, audit, or findings. | Returns findings only — does NOT rewrite the plan unless the user explicitly asks. |
| **Reconcile** | User provides both a spec and a plan, or asks to check alignment between them. | Returns findings on mismatches between spec, plan, and codebase. Does NOT apply edits without approval. |
| **Review & Patch** | User provides a plan and explicitly asks to fix/correct/apply findings. | Applies corrections to the plan file. |

**Default to Review mode if ambiguous.** Only write files when the mode clearly requires it.

## Inputs

- **$ARGUMENTS**: One or two file paths depending on mode.
- **Plan template**: `<planned_features_root>/feature_templates/implementation-plan-template.md`
- **Project context**: `<conventions_doc>`, `<arch_doc>`, `<state_doc>`

---

## Workflow — Generate mode

### Step 1: Gather context

Read in order:

1. `<conventions_doc>` — project conventions, absolute rules, data model, stack
2. `<arch_doc>` — system design, boundaries, critical flows, frontend page structure
3. `<state_doc>` — current priorities, recent changes, known debt, migration head
4. `<planned_features_root>/feature_templates/implementation-plan-template.md`
5. The approved feature spec at $ARGUMENTS — every FR, AC, data model change, API contract, and test requirement

### Step 2: Codebase exploration

Before writing any stories, explore the codebase to ground the plan in reality:

1. **Verify the spec's Section 2 (Current state audit)** — read every file referenced. Confirm paths, function signatures, and column names are still accurate.
2. **Read existing patterns for each layer the plan will touch:**
   - If the plan adds a migration: `ls <migrations_dir>` to find the current head; use the next sequential revision number per your project's convention.
   - If the plan adds a router: read your project's main entry point to see how routers are registered (prefix, tags, dependencies).
   - If the plan adds a service: read an existing service to confirm patterns (lifecycle, quota check, error handling).
   - If the plan adds a repo function: read the relevant repo file to confirm conventions (parameter order, flush vs commit, return types).
   - If the plan modifies frontend: read the target component to get current line count, section structure, state variables, props, and insertion points.
3. **Identify analogous implementations** — find the closest existing feature to the one being planned. Use it as the structural template for stories.

### Step 3: Generate the plan

Using the template structure, build the plan from the spec:

**Critical rules for plan generation:**

- **Every story must trace to at least one FR from the spec.** Use the spec's traceability matrix as the starting point.
- **Every endpoint in the spec's §8 must appear in exactly one story's endpoint table.** Count them and verify.
- **Every error code in the spec must appear in the plan's contract test tasks.** Count them and verify.
- **New file paths must match the actual project layout.** Don't guess migration directories, router paths, or test file locations.
- **Modified file tables must reference files that actually exist.** Glob for each one.
- **Key interfaces must use types and patterns from the existing codebase.**
- **Frontend stories must include UI element inventories and state dependency analysis** when creating, moving, or removing components.
- **Analogous markup patterns must include actual JSX/template code** copied from the codebase, not just "follow the X pattern" references.
- **Error shapes in endpoint tables must match the per-route verification from the spec.** Do not assume a universal envelope.
- **Auth dependencies in endpoint tables must match the spec's API convention check.**
- **E2E test tasks must run against the real backend and exercise the browser layer.** No request-mocking-based assertions. Tests must use real browser interactions (navigate, fill forms, click buttons, assert DOM). Anchor to a real-backend reference pattern from `PROJECT_CONFIG.md`.
- **Never hardcode third-party model names.** Reference your project's abstraction.

### Step 4: Plan-internal consistency review (Pass 1)

Execute the plan template's consistency review systematically:

1. **Spec ↔ plan endpoint count**: count endpoints in spec §8.1; verify the plan covers every one. Error codes in spec §8.5 must appear in plan endpoint tables and contract test descriptions.
2. **Spec ↔ plan FR coverage**: verify every FR has a row in the plan's traceability table and is assigned to at least one story.
3. **Story internal consistency**: for each story:
   - Endpoint table fields match the schemas (names, types).
   - DoD assertions reference correct error codes and HTTP status codes.
   - New files are not claimed by multiple stories (no ownership conflict).
   - Modified files exist in the codebase (glob for each).
4. **Test file count and assignment**: count test files across all stories. Verify they match the testing workstream inventory. **Every test file in the workstream must be assigned to exactly one story's DoD** — orphaned test files will be skipped during execution. If a test file doesn't naturally belong to a single story (e.g., integration tests spanning multiple stories), assign it to the last story in the epic that completes the testable surface.
5. **Gate arithmetic**: verify epic/phase gate statements match actual endpoint/story counts.
6. **Open questions resolved**: confirm every open question from the spec is resolved.
7. **Frontend UI Guidance completeness** (REQUIRED if any story has frontend scope): Verify the plan includes a plan-level "UI Guidance" section with ALL required subsections. If any are missing, the plan is incomplete:
   - **Insertion point** — exact lines being replaced/modified
   - **Analogous markup patterns** — actual copy-pasteable code (not just "follow the X pattern") for every new UI section
   - **Layout and structure** — visual hierarchy, column arrangement, responsive behavior
   - **Confirmation/modal dialog pattern** — actual code if dialogs are included
   - **Visual consistency table** — maps every new UI element to its CSS class/pattern source
   - **Component composition** — whether new UI is inline or extracted, with rationale
   - **Interaction behavior table** — every user action → frontend behavior → API call
   - **Handler function patterns** — actual handler code for key events
   - **Information architecture placement** — where the feature lives in navigation, what comes before/after
   - **Tooltips and contextual help** — for every non-obvious UI element in the spec's tooltip inventory
   - **Legacy behavior parity** (REQUIRED when any story deletes/replaces a user-facing component >100 LOC): the plan MUST include a "Legacy behavior parity" table listing every validation, loading state, error handler, disabled condition, optimistic update, button-label state, tooltip, and confirmation dialog shipped in the deleted/moved component. Each row must state either "Preserved in: `<file>:<symbol>`" or "Intentionally dropped — reason: `<product/spec citation>`". The corresponding story's DoD must assert (unit, integration, or E2E) every "Preserved" row. **Why:** AI agents cannot visually verify their output; "TypeScript compiles" and "happy path renders" don't exercise a missing `minLength={20}` check or a button that re-fires while a request is in flight.

Record every finding in the verification ledger.

### Step 5: Codebase accuracy review (Pass 2)

Verify the plan's claims against the actual codebase:

1. **Infrastructure paths**: verify migration directory, migration head, router registration pattern, test file locations.
2. **State variable names and locations**: for frontend stories, grep for each state variable listed in removal/move lists. Verify it exists where claimed.
3. **Function names and signatures**: for key interfaces, grep to confirm functions exist.
4. **Line number references**: for insertion points and analogous patterns, verify line numbers are within ~20 lines of actual code.
5. **API endpoints in frontend**: verify that fetch calls reference endpoints that exist in the backend routers.
6. **State dependencies**: for refactors, verify state being removed isn't referenced by components the plan doesn't account for.
7. **Frontend data plumbing**: for every prop a story passes to a component, verify the parent has access to that data.
8. **Persistence scope**: for `localStorage`/`sessionStorage` usage, verify task description and DoD agree on persistence scope.
9. **Legacy-delete behavior parity**: for every story that deletes/replaces a user-facing component >100 LOC, confirm the plan includes a Legacy Behavior Parity table. For each "Preserved in: …" entry, verify the named file/symbol exists. For each "Intentionally dropped" entry, verify the cited spec section or product-decision reference actually authorizes the drop. Additionally, grep the deleted file for `onChange`, `onClick`, `onSubmit`, `onBlur`, `maxLength=`, `minLength=`, `pattern=`, `disabled=`, `aria-disabled`, `role="alert"`, `catch (`, `setError`, `setLoading`, `confirm(` and check that each match appears in the parity table with a verdict.
10. **Enumerated value contract verification**: for every filter dropdown, sort control, status badge, tier label, role selector, or other `<select>` whose wire value the backend validates against a fixed allowlist:
    - Confirm the spec has §8.4 "Enumerated value contracts" citing the backend source-of-truth file.
    - Grep that backend file to enumerate the exact wire values. Build a 3-column verification: (1) values in backend, (2) values in spec, (3) values the plan's frontend story will render. All three columns MUST match character-for-character.
    - Flag any story that adds a frontend `<select>` / filter chip / badge variant without explicitly listing the wire values AND the backend source file in the UI element inventory.
    - Require the plan to specify a source-of-truth comment above each generated option array (e.g., `// Values must match <backend_path>:<symbol>`). Missing comments make future drift harder to prevent.
    **Why:** Phantom values ("mid" tier, "drafting" bucket) look plausible but produce validation errors. Typecheckers, lint, unit tests do not catch this — only a grep-against-source audit does.
11. **Audit-event coverage verification** (only if your project has audit-log infrastructure): for every endpoint or service function the plan adds/modifies that mutates state:
    - Confirm the spec's audit-event instrumentation matrix lists the mutation site with a chosen event type.
    - For new event types: verify the plan has a story to add the type to the canonical event-type catalog.
    - Confirm the emission story specifies **atomic emission** — the audit_log INSERT happens inside the same transaction as the primary mutation, before commit.
    - Confirm the plan includes a contract test asserting metadata shape on the audit row.
    - Mutations that do NOT need an audit event must be explicitly justified.

Record every finding in the verification ledger.

### Step 6: Cross-model review

This step is **mandatory** when a cross-model reviewer is configured. The protocol mirrors the spec-gen workflow.

**API key resolution:**
- Parse `<secondary_api_key_envvar>` from `<secondary_api_key_source>`.
- Use the snippet in `PROJECT_CONFIG.md` to invoke `<secondary_model>` at `<secondary_api_base>`.

**Reviewer roles** (both fulfilled by the secondary model):

| Role | Focus areas |
|---|---|
| **Pass A: Structural & Contract** | Spec-plan FR traceability, endpoint count parity, error code coverage, story endpoint/schema consistency, gate arithmetic, migration path accuracy |
| **Pass B: Implementation & Risk** | Key interface feasibility, frontend state dependencies, analogous pattern accuracy, test layer completeness, sequencing risks, downstream impact of story ordering |

**Review protocol:**

1. Send the full plan text AND the source spec to the secondary model. Request findings as structured output: claim, evidence (file:line), severity, reviewer pass (A or B).

   **On cycle 2 and later — include the rejection log from earlier cycles** in the system prompt so repeat findings don't burn time. See spec-gen Step 6 for the exact format.

2. **Primary-model adjudication:** Accept (cite evidence) / Reject (cite counter-evidence from code) / Escalate (open question for user). Rejections without cited counter-evidence are not allowed.

3. Accepted corrections are staged, not applied immediately. Major corrections require user approval at the findings gate (Step 8).

**Fallback if cross-model reviewer is unavailable:** Same as spec-gen. Alert the user, log the skip, proceed with primary-only review.

### Step 7: Cross-model convergence loop

After the primary applies accepted corrections, determine whether another review cycle is needed:

**Re-review trigger:** If any accepted correction changed a **major** element (endpoint table, key interface, file path, migration detail, story scope, gate condition, or test strategy), send the corrected plan back to the secondary model.

**Cross-model loop stop rules:**
- Stop when the secondary reports no new High-severity findings AND the primary has no unresolved accepted changes.
- Stop when the secondary returns only previously-rejected findings (no new information).
- Stop after a maximum of 3 cycles. If convergence isn't reached, present the remaining disagreements to the user.

**Internal convergence (primary-only):** After the cross-model loop completes, the primary may run additional internal review passes if needed:
- If two consecutive primary-only passes produce only wording or formatting edits, stop.
- Maximum 2 additional primary-only passes after the cross-model loop.

**Convergence criteria**: A pass is "clean" if it produces no changes to:
- Story endpoint tables or schemas
- New/Modified file tables
- Key interface signatures
- Migration file paths or revision numbers
- Epic/phase gate conditions
- Test task scope or file assignments
- Sequencing or dependency declarations

### Step 8: Findings gate

Before writing any files, classify all staged findings into:

- **Major** (High severity): Changes to endpoint contracts, key interfaces, file ownership, migration details, story scope, sequencing, or gate conditions.
- **Minor** (Medium/Low severity): Wording, formatting, DoD phrasing, documentation references, task ordering within a story.

**Gate rules:**
- **Major findings**: Present to the user for confirmation before applying. Do not write files until the user approves.
- **Minor findings**: May be applied without explicit confirmation, but include them in the review log.
- If there are no major findings, proceed directly to writing.

### Step 9: Write the plan

Default location: same directory as the feature spec, named `implementation_plan.md`. Ask the user if they have a preferred location.

### Step 10: Track deferred phases

**This step is MANDATORY when the plan covers only a subset of the spec's phases.**

1. Read the spec's "Phase boundaries" section. Identify any phases NOT covered by this implementation plan.
2. For each deferred phase, check whether a tracking file already exists.
3. If no tracking file exists, create one at `<planned_features_root>/<feature_dir>/phase<N>_idea.md` following the `idea.md` template pattern. Include:
   - Origin pointer to the spec file and line numbers
   - The deferred FRs with enough context to generate a future spec/plan
   - Why the work was deferred
   - Dependencies on the implemented phase
4. Inform the user about the deferred work tracking file.

### Step 11: Update project docs

Evaluate whether these files need updates:

- `<state_doc>` — if this plan changes active priorities or introduces new planned work
- `<arch_doc>` — if the plan reveals architectural decisions not yet documented

Present proposed doc updates to the user for approval before writing.

### Step 12: Update pipeline status

**This step is MANDATORY in Generate mode.** Update `<planned_features_root>/<feature_dir>/pipeline_status.md`:

```markdown
## Plan
- Status: Approved
- Date: <YYYY-MM-DD>
- File: implementation_plan.md
- Cross-model review: <secondary_model> passed (<N> cycles)
- Stories: <N total across M epics>
- Phases covered: <list of phases>
```

If `pipeline_status.md` does not exist yet, create the full file with Idea and Spec sections populated based on existing artifacts.

---

## Workflow — Review mode

1. **Gather context**: Read project context files, the plan at $ARGUMENTS, and the plan's referenced feature spec.
2. **Run Pass 1 (plan-internal consistency)** and **Pass 2 (codebase accuracy)** against the existing plan.
3. **Build the verification ledger** for every material claim.
4. **Deferred phase audit**: Read the source spec's "Phase boundaries". Report any untracked deferred phases as a **Medium** finding.
5. **Cross-model review (optional but recommended):** If the secondary model is available, send the plan and its source spec for external review using the same protocol as Generate mode Step 6.
6. **Return findings only.** Do not rewrite the plan. Present findings with severity, source, location, claim vs. reality, suggested correction.
7. **Flag open questions** that need the user's input.

---

## Workflow — Reconcile mode

1. **Read both documents** and the project context files.
2. **Spec → plan traceability**: List every FR, endpoint, error code, and AC from the spec. For each, check whether the plan covers it. Flag gaps.
3. **Plan → spec traceability**: List every story endpoint, key interface, and new file from the plan. For each, check whether it traces to a spec FR. Flag orphaned stories.
4. **Deferred phase audit**: If the spec defines phases not covered by the plan, check whether each deferred phase has a tracking artifact.
5. **Codebase drift**: If time has passed since the spec was written, check whether the codebase has changed in ways that affect the plan.
6. **Return the alignment report** with recommendations.

---

## Workflow — Review & Patch mode

1. **Gather context**: Read project context, the plan, and the plan's referenced feature spec.
2. **Verify each finding** against the codebase and spec.
3. **Classify findings** into Major and Minor.
4. **Present Major findings** to the user with proposed corrections. Wait for approval.
5. **Apply approved corrections** to the plan file. Apply Minor corrections without gating.
6. **Run a single verification pass** on the patched plan.
7. **Return the verification ledger** and a summary of what was changed.

---

## Verification ledger

For every material claim in the plan (file paths, endpoint tables, key interfaces, migration details, state variables, test file assignments), maintain a ledger:

| Claim | Verified by | Status |
|---|---|---|
| Migration dir is `<migrations_dir>` | `ls <migrations_dir>` | Verified |
| Current migration head is `<id>` | `ls <migrations_dir> | sort | tail -1` | Verified |
| `create_X()` accepts `<arg>` kwarg | Read `<file>:43` — uses `**kwargs` | Verified — kwargs pass-through |
| Story 1.2 modifies `<file>` | `glob <file>` | Verified |
| Frontend `<field>` available in `<page>` | Read `<page>` — not currently fetched | **Corrected** — story must add fetch |

Include the ledger in the review log output.

## Common pitfalls to avoid

1. **Wrong migration directory** — `ls` the actual path; don't assume.
2. **Wrong migration head** — check the actual versions directory, not `<state_doc>` (may be stale).
3. **Router registration assumptions** — read your project's main entry point to see how routers are mounted.
4. **Frontend stories without reading the component first** — never write a UI element inventory or state dependency analysis without reading the actual component file.
5. **"Follow the X pattern" without copying the markup** — always include the actual code from the analogous section.
6. **Endpoint tables that don't match the spec** — must exactly match the spec's §8.
7. **Stories that claim to modify files they don't need to** — grep for actual usage before listing.
8. **Test tasks pointing at mocked E2E suites** — anchor new E2E tasks to real-backend suites.
9. **Key interfaces that don't match existing layer conventions** — read the layer before writing signatures.
10. **Frontend data plumbing gaps** — if a story says "pass X as a prop," verify the parent has X. Most common frontend plan failure.
11. **Missing plan-level UI Guidance section** — story-level inventories are necessary but NOT sufficient. The plan-level section provides the unambiguous markup patterns that prevent implementation rework.
12. **Persistence scope mismatch** — `localStorage` persists forever; `sessionStorage` clears on tab close. If task says one and DoD says the other, that's a bug.
13. **Gate arithmetic errors** — if a gate says "all 8 endpoints live" but the stories define 6, the gate is wrong.
14. **Invented enum / filter / dropdown values in frontend stories** — frontend stories that define a `<select>`, filter dropdown, or option list whose values are sent back to the backend MUST enumerate the exact wire values AND cite the backend source-of-truth file. Plans that only specify user-facing labels (e.g., "Paused" without `paused` being in the backend's status allowlist) produce frontend bugs that typecheckers, lint, and unit tests will not catch — the bug only surfaces as a validation error or silent zero-result filter in the browser.
15. **Missing Legacy Behavior Parity table on delete-and-replace stories** — when a story deletes/replaces a user-facing component >100 LOC, omitting the parity table is how client-side validations, inflight-disable states, and confirmation dialogs silently disappear.

## Review log

At the end, provide a summary:
- Mode used (Generate / Review / Reconcile / Review & Patch)
- Source spec referenced
- Number of review passes performed
- Verification ledger (material claims checked)
- Key inaccuracies found and corrected (or reported, in Review mode)
- Spec-plan alignment status (all FRs covered / gaps found)
- Any open questions that need user input
- Proposed doc updates (if any)
