---
name: guide-gen
pipeline-stage: 3.1
pipeline-role: conditional — invoked from impl-execute when tenant-facing UI changes
description: "Generate, audit, or regenerate tenant-facing walkthrough guides with browser-captured screenshots and a cross-model visual audit. Use when: creating a new walkthrough guide, auditing existing guide screenshots against the codebase, regenerating screenshots after UI changes, or reviewing guide accuracy. Trigger phrases: generate guide, create walkthrough, audit guide, regenerate walkthrough screenshots, review guide accuracy, visual audit guide."
argument-hint: "[flow description or guide number, e.g. 'signup and onboarding' or '01'] [optional: '--audit' to audit existing guide without regenerating, '--regen' to regenerate screenshots only]"
allowed-tools: Read, Glob, Grep, Bash, Write, Edit, Agent, WebFetch, WebSearch, TodoWrite
user-invocable: true
---

# Walkthrough Guide Generator & Visual Auditor

> **DORMANT** until your project has a tenant-facing web frontend. Do NOT invoke this skill before the web stack lands. The patterns below describe how the skill will work once activated; concrete file paths (`<frontend_root>`, guide directories) need to exist first.

You generate, audit, and maintain user-facing walkthrough guides. Each guide is a set of browser-captured screenshots with captions, served in-app via a `GuideViewer` component.

> Read `PROJECT_CONFIG.md` at the repo root before starting. Every `<placeholder>` resolves from there.

The core value of this skill is **visual verification**: every screenshot is compared against the codebase's expected state to catch UI bugs, missing features, stale content, and broken flows — before a tenant ever sees them.

## Inputs

- **Flow description or guide number**: e.g., `"signup and onboarding"`, `"first run"`, or `"01"` (references `01_signup_and_onboarding`).
- **Optional flags**:
  - `--audit` — audit an existing guide's screenshots against the codebase without regenerating. Produces findings only.
  - `--regen` — regenerate screenshots for an existing guide (re-run the automation spec, then audit).
  - Omitted (default) — full generate mode: analyze codebase, write spec, capture screenshots, audit, write guide assets.

## Modes

| Mode | When to use | Behavior |
|---|---|---|
| **Generate** | New guide from a flow description | Analyze codebase → write automation spec → capture screenshots → visual audit → cross-model review → write guide assets |
| **Audit** | Review existing guide accuracy | Read existing screenshots → build expected-state model from code → compare → report findings → create bug/idea files |
| **Regenerate** | UI changed, screenshots stale | Re-run existing automation spec → visual audit → update assets |

## Project context

Read these files before starting:

- `<conventions_doc>` — project conventions, stack, data model
- `<arch_doc>` — system design, page structure
- `docs/08_guides/README.md` (or your project's guides index) — guide conventions, directory structure, walkthrough inventory
- Your guide-trigger component — route-to-guide mapping
- Your guide-viewer component — how guides are rendered in-app

## Directory structure (example)

```
<frontend_root>/public/guides/<guide_id>/    # Single source of truth for assets
  metadata.json                              # Title, description, slides array
  01-screenshot-slug.png                     # Screenshots (served by your frontend)
  ...

<frontend_root>/tests/e2e/guides/            # Automation specs
  <NN>_<slug>.spec.<ext>

docs/08_guides/
  README.md                                  # Conventions and inventory only
```

Adjust paths to match your project's conventions.

## Walkthrough inventory

The walkthrough inventory will be authored when your project's UI matures. Common first guides:

| # | Guide ID | Flow | Route prefix |
|---|---|---|---|
| 01 | `01_<first_flow>` | <description> | `<route>` |
| 02 | `02_<second_flow>` | <description> | `<route>` |
| ... | ... | ... | ... |

---

## Workflow — Generate mode

### Step 1: Analyze the codebase

Build an **expected-state model** for the flow — what the user should see at each step:

1. **Identify the pages/components** involved in the flow. Read each page file and its key components.
2. **For each screen in the flow**, document:
   - URL and route
   - Heading text, form fields, buttons, badges visible
   - Data-driven elements (how many plan options? which filter tabs? what status badges?)
   - Conditional UI (what shows for trial vs paid? what shows with no data?)
3. **Identify API endpoints** called by each page — read the backend route to understand what data shapes the UI.
4. **Build the expected-state checklist**: a structured list of assertions per screen.

Example expected-state entry:
```
Screen: /<route>/{id}
Expected elements:
  - Heading: <item> name
  - Status badge: one of <enumerated_values>
  - <table> with columns: <columns>
  - <Action> button: visible only when status="<state>"
  - <Panel>: visible only when an associated <related_object> exists
Source: <frontend_root>/<page_path> — depends on `useX(id)` hook in <hooks_path>
```

### Step 2: Write the automation spec

Create `<frontend_root>/tests/e2e/guides/<NN>_<slug>.spec.<ext>` following the established patterns:

**Required conventions:**
- Import helpers from `../helpers/` (your project's test helpers — session setup, data seeding, cleanup).
- Write screenshots to the configured screenshot directory.
- Dismiss cookie consent banners and other onboarding overlays at the start.
- Hide floating overlays (extensions, dev indicators) via a global init script.
- Settle the page before each screenshot (scroll to top, wait for animations).
- Clean up created tests in your project's teardown pattern.
- Use semantic locators (role / label / text) — not CSS selectors.
- Add full-page capture for long pages that extend below the viewport.

**Screenshot naming:** `NN-descriptive-slug.png` (e.g., `01-cluster-list.png`).

### Step 3: Run the spec

Run the automation spec using your project's E2E test command. Specify the config that uses Playwright's bundled Chromium (or your project's automation-friendly browser) with extensions disabled.

**Prerequisites check:** Before running, verify:
1. Backend is responding (health check).
2. Frontend is responding.
3. If either is down, start the dev stack and wait for both to come up.

**If the spec fails:** Read the error, check the failure screenshot, fix the spec, and re-run. Common issues:
- Rate limiter blocking the API (restart backend if it has in-memory rate limiting).
- Authentication redirect (set up session correctly).
- Form field placeholder mismatch (check actual placeholder text in the component).
- Navigation losing session context (use in-page navigation instead of full reloads).

### Step 4: Visual audit (Pass 1 — primary model)

Read each captured screenshot and compare against the expected-state model from Step 1:

For each screenshot:

1. **Read the PNG file** using the Read tool (it renders images for the primary model).
2. **Check every item** in the expected-state checklist for that screen:
   - Are all expected UI elements present?
   - Are text labels correct?
   - Are counts correct (e.g., 5 plan options, not 3)?
   - Is the layout reasonable (no clipped content, no overlapping elements)?
   - Are there any unexpected artifacts (extension icons, dev indicators, cookie banners)?
3. **Record findings** as:
   - **Pass** — screenshot matches expected state
   - **UI Bug** — code says X should be there, screenshot shows it's missing or wrong
   - **Spec Issue** — the automation spec captured the wrong state (wrong page, bad timing)
   - **Cosmetic** — minor visual issue (clipped text, awkward spacing) that doesn't affect functionality

### Step 5: Cross-model visual review (Pass 2 — secondary model)

**This step is MANDATORY for Generate mode.**

Send each screenshot + its expected-state checklist to the secondary model for an independent visual audit.

**API key resolution:** Per `PROJECT_CONFIG.md` — parse `<secondary_api_key_envvar>` from `<secondary_api_key_source>`. Use model `<secondary_model>` at `<secondary_api_base>` with the correct token param.

**Important: text-only secondary models cannot read image files directly.** Instead, send:
- The expected-state checklist for each screen
- The automation spec source (showing what actions were taken)
- A text description of what the primary model observed in each screenshot during Pass 1
- Ask the secondary to identify any expected elements that the primary may have missed or normalized away

If your secondary model is multi-modal, send the screenshots directly.

**Review prompt:**
```
You are auditing a product walkthrough guide against its expected state.
For each screen, I'll provide:
  1. What the code says SHOULD be visible (expected-state checklist)
  2. What was observed in the screenshot (Pass 1 findings)
  3. The automation spec that captured it

Check for:
- Missing UI elements that the code defines but weren't observed
- Incorrect counts (e.g., code defines 5 items, only 3 were seen)
- Stale labels or copy that doesn't match the code
- Flow logic issues (wrong redirect, missing step)
- Accessibility gaps (missing labels, no keyboard nav)

Return findings as JSON: {"findings": [{"severity": "High/Medium/Low",
"screen": "NN-slug", "expected": "what should be there",
"observed": "what was seen instead", "source": "file:line",
"category": "ui_bug|missing_feature|spec_issue|cosmetic"}]}
```

**Adjudication:** For each finding:
- **Accept** — cite the code evidence, stage the action.
- **Reject** — cite counter-evidence from screenshot or code.
- **Escalate** — present to user for decision.

### Step 5b: Completeness check

Verify the guide covers the complete user journey for the flow it describes:

1. **Entry point:** Does the first slide show the starting state the user would actually see? If the guide is for an authenticated flow, does it start on the correct page/tab?
2. **Action continuity:** Does each slide end with a clear action that leads to the next slide? Are there any gaps where the user would be stuck between slides?
3. **Exit point:** Does the last slide leave the user in a state where they can either: proceed independently (they know what to do next), OR pick up the next guide in the sequence (with an explicit bridge in the caption)?
4. **No dead ends:** If the guide ends at a prompt (e.g., "No items configured"), does the caption tell the user exactly what to do AND reference the follow-up guide?
5. **Minimum viable flow:** Does the guide cover enough steps that the user can accomplish the stated goal? A "First Run" guide that doesn't show results is incomplete. A "Send" guide that doesn't show the send button is incomplete.

If the guide is incomplete, extend it or adjust the scope and bridge to the next guide.

### Step 5c: Route relevance check

Verify the guide is mapped to the correct pages in your route-to-guide mapping:

1. **Read the mapping** and check which route prefixes are mapped to this guide.
2. **For each slide**, verify the screenshot was taken on a page that matches one of the mapped route prefixes.
3. **Check for missing mappings:** if the guide shows pages not in its route mapping, add the route or remove those slides.
4. **Check for wrong mappings:** if the guide is mapped to a page where its content isn't relevant, remove that mapping.
5. **Verify the guide is listed in the guide catalog**. If it's a new guide, add it.

### Step 6: Findings gate

Classify all findings from both passes (including completeness and route relevance):

**For UI Bugs (code is right, UI is wrong):**
Create a bug tracking file at `<planned_features_root>/bug_<description>/idea.md` following the idea template with:
- **Status:** `Bug — identified by guide-gen visual audit`
- **Origin:** `guide-gen audit of guide <guide_id>, screenshot <NN-slug.png>`
- **Problem:** What's wrong and where (with file:line references)
- **Proposed capabilities:** The fix needed
- **Scope signals:** Which layers need changes

**For Missing Features (intentional gap, not a bug):**
Create a feature tracking file at `<planned_features_root>/<feature_name>/idea.md`.

**For Spec Issues:**
Fix the automation spec and re-run. Do not create tracking files.

**For Cosmetic Issues:**
Note in the audit log but do not create tracking files unless the user requests it.

**Present all findings to the user before proceeding.** Major findings (High severity) require user confirmation.

### Step 7: Write guide assets

After findings are resolved:

1. **metadata.json** → `<frontend_root>/public/guides/<guide_id>/metadata.json`
   ```json
   {
     "title": "Human-readable guide title",
     "description": "One-sentence description for the Guides page",
     "order": <number>,
     "tags": ["tag1", "tag2"],
     "estimated_time": "N minutes",
     "screenshots": [
       { "file": "01-slug.png", "caption": "What this screen shows" },
       ...
     ]
   }
   ```

2. **script.md** → `<frontend_root>/public/guides/<guide_id>/script.md`
   - One `## NN — Title` section per screenshot
   - 1-2 sentences of narrative context
   - `![alt text](/guides/<guide_id>/NN-slug.png)` image reference

3. **Route mapping entry** → update your guide-trigger component
   - Add the route prefix → guide ID mapping
   - Only add if the guide is relevant to an unauthenticated or specific page

### Step 8: Update inventory

Update `docs/08_guides/README.md` walkthrough inventory table — mark the guide as Complete.

### Step 9: Commit

Stage all new/modified files and commit. If bug/idea files were created, include them in the commit.

---

## Workflow — Audit mode

When auditing an existing guide (`--audit`):

1. **Read the existing guide** — metadata.json, screenshots, spec.
2. **Build expected-state model** from the current codebase (Step 1 of Generate).
3. **Visual audit** each screenshot against the model (Step 4 of Generate).
4. **Cross-model review** via the secondary model (Step 5 of Generate).
5. **Report findings** — do NOT regenerate screenshots or modify guide assets.
6. **Create bug/idea files** for any UI bugs or missing features found.
7. **Present findings to user** with recommendations:
   - Fix the code (create bug file) → then regenerate with `--regen`.
   - Update the spec (spec issue) → then regenerate with `--regen`.
   - Accept as-is (cosmetic only).

---

## Workflow — Regenerate mode

When regenerating an existing guide (`--regen`):

1. **Read the existing automation spec** — do not rewrite it unless it fails.
2. **Re-run the spec** to capture fresh screenshots.
3. **Run visual audit** (Pass 1 + Pass 2) on the new screenshots.
4. **If findings exist**, follow the Findings gate (Step 6 of Generate).
5. **Update guide assets** — copy new screenshots, update metadata.json if captions changed.
6. **Commit** the updated screenshots.

---

## Automation spec patterns

### Auth patterns by flow type

**Unauthenticated flows (signup, login):** Just `await page.goto("/<route>")` and dismiss cookie banners.

**Authenticated flows:** Use your project's session-seeding helper to create a tenant + session, then navigate.

**Flows requiring existing data:** Seed via your project's admin/test API endpoints before navigating.

### Screenshot capture pattern

```
// Scroll to top, wait for animations, capture
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(400);
await page.screenshot({
  path: <screenshots_dir> + "/NN-slug.png",
  fullPage: false, // true for long pages
});
```

### Overlay hiding pattern

Use your automation tool's init-script mechanism to install a MutationObserver that hides floating overlays (extensions, dev indicators) by checking for fixed-position high-z-index elements at the document root.

---

## Rules

1. **Never skip the visual audit.** Every screenshot must be read and compared against the expected-state model.
2. **Always use `<secondary_model>` for cross-model review** in Generate mode. Never substitute a same-family model.
3. **Always create bug files** for UI discrepancies where the code is correct but the UI is wrong. Use the `bug_` prefix.
4. **Never modify application code** to fix bugs found during the audit. Create the tracking file and move on. The fix belongs in a separate PR via the normal spec → plan → execute pipeline.
5. **Always dismiss cookie banners and onboarding overlays** before capturing screenshots.
6. **Always check that dev servers are running** before executing the automation spec.
7. **Screenshots are the single source of truth** — they live in `<frontend_root>/public/guides/` only. No duplicate copies.
8. **Clean up test data** — every automation spec must clean up created tenants/users in teardown.
9. **Use the automation-friendly browser config** — not system Chrome. Disable extensions to avoid browser extension artifacts in screenshots.
10. **Present findings to the user** before creating bug/idea files. Major findings require confirmation.
11. **Captions must be action-oriented instructions.** Every caption starts with a verb telling the user what to do: "Click", "Enter", "Select", "Scroll", "Open". Never describe outcomes — describe actions. Bad: "The Studies tab shows your studies." Good: "Click the Studies tab to see your study trial logs."
12. **Guides must be complete.** A guide that ends before the user can accomplish the stated goal is not done. If a technical limitation prevents completion, bridge to the next guide explicitly in the last caption.
13. **Route mappings must be verified.** Every guide must be mapped to the correct pages and listed in the guide catalog. A guide should only appear on pages where its content is relevant to what the user is currently doing.
