---
name: spec-gen
pipeline-stage: 1
pipeline-role: idea → feature_spec.md
description: "Generate, review, or reconcile feature specifications. Use when: creating new feature specs, reviewing existing specs for accuracy, reconciling input briefs against specs, auditing planned feature docs, or patching spec inaccuracies. Trigger phrases: review existing feature spec, spec accuracy audit, reconcile feature brief, planned feature review, generate feature spec."
argument-hint: "[path(s): single file for Generate/Review/Review & Patch, or 'input.md spec.md' for Reconcile]"
allowed-tools: Read, Glob, Grep, Bash, Write, Edit, Agent
user-invocable: true
---

# Feature Specification Generator & Reviewer

You are working with feature specifications. Depending on the mode, you either generate a new spec, review an existing spec for accuracy, or reconcile an input brief against an existing spec.

> Read `PROJECT_CONFIG.md` at the repo root before starting. Every `<placeholder>` resolves from there.

## Mode selection

Before starting, determine which mode applies based on the user's request and the argument provided:

| Mode | When to use | Writing behavior |
|---|---|---|
| **Generate** | User provides an input brief (markdown describing a feature). No spec exists yet. | Creates a new spec file. |
| **Review** | User provides a path to an existing spec. Asks for accuracy review, audit, or findings. | Returns findings only — does NOT rewrite the spec unless the user explicitly asks. |
| **Reconcile** | User provides both an input brief and an existing spec, or asks to align them. | Returns findings on mismatches and proposes specific edits, but does NOT apply them without approval. |
| **Review & Patch** | User provides a spec and explicitly asks to fix/correct/apply findings. | Applies corrections to the spec file. |

**Default to Review mode if ambiguous.** Only write files when the mode clearly requires it.

## Inputs

- **$ARGUMENTS**: One or two file paths depending on mode:
  - **Generate**: single path to the input brief (e.g., `<planned_features_root>/<feature>/idea.md`)
  - **Review / Review & Patch**: single path to the existing spec (e.g., `<planned_features_root>/<feature>/feature_spec.md`)
  - **Reconcile**: two paths separated by a space — input brief first, then spec
- **Spec template**: `<planned_features_root>/feature_templates/feature-spec-template.md`
- **Project context**: `<conventions_doc>`, `<arch_doc>`, `<state_doc>`

## Workflow — Generate mode

### Step 1: Gather context

Read these files to understand the project:

1. `<conventions_doc>` — project conventions, absolute rules, data model, stack
2. `<arch_doc>` — system design, boundaries, critical flows
3. `<state_doc>` — current priorities, recent changes, known debt
4. `<planned_features_root>/feature_templates/feature-spec-template.md` — the output template
5. The user's input document at $ARGUMENTS

### Step 2: Generate initial spec

Using the template structure, fill in every section with concrete, specific content derived from:

- The user's input document (the "what" and "why")
- The codebase context (the "how" — existing patterns, conventions, data model, API shapes)

**Critical rules for spec generation:**

- **Every file path, table name, column name, endpoint, and function reference must be verified against the actual codebase.** Do not assume — grep/glob/read to confirm.
- **Error shapes must be verified per-route, not assumed globally.** Repos often have mixed error patterns: some routes return structured `detail` objects, others return plain strings. For each endpoint referenced in the spec: (1) read the route's error handling code, (2) check for a contract test that asserts on the response shape, (3) copy the exact shape found. Do not invent a universal envelope — verify per-route.
- **Auth patterns must be verified per-route.** Read the actual route function signature and its dependency chain. Don't assume an auth mechanism — many tenant routes use a specific membership check; many operator routes are unauthenticated.
- **API conventions must match existing routers.** Read actual router files to confirm prefix patterns, auth dependencies, return type annotations, and response shapes.
- **Return type annotations on routes determine response shape.** If a route returns a list, the response example must be an array, not a bare object. Read the function signature.
- **Data model references must match the current ORM models.** Read the model files to verify column names, types, and relationships.
- **Domain rules must match the source of truth.** Read the domain layer to confirm state transitions, quota logic, and validation rules.
- **Never hardcode third-party model names.** If your project uses an LLM/ML model behind an abstraction, reference the abstraction in the spec — not a specific model ID.
- **E2E test coverage claims must distinguish real-backend from mocked tests.** Do not cite request-mocking-based tests as true end-to-end coverage. Classify them as "mocked UI regression coverage" or "existing test debt." When recommending new E2E coverage, anchor to real-backend suites.

### Step 3: Codebase accuracy review (Pass 1)

Systematically verify every claim in the spec against the codebase:

1. **File paths**: Glob for every file/directory referenced. Do they exist? Are the paths correct?
2. **Table/column names**: Read the ORM models for every table referenced. Do the columns exist with the stated types?
3. **API endpoints**: Read the router files. Do referenced endpoints exist? Are methods/paths correct? What is the return type annotation?
4. **Function names and behavior**: Grep for every function referenced. Does it exist? Is the signature correct? **Read the function body** for any function whose behavioral semantics are claimed in the spec (e.g., "create_X prevents overwriting"). Do not infer behavior from the function name alone.
5. **Domain rules**: Read domain layer files. Are transition rules, quota logic, and validation rules accurately described?
6. **Existing implementations (Section 2)**: Search for all existing code that the feature touches. Are there implementations the spec missed?
7. **Downstream consumers**: For every field being changed or added, grep for all code that *reads* that field — not just the code that writes it. Missing downstream impact is a common spec failure.
8. **Navigation/link impact**: Search for URL references that will change.
9. **Test impact**: Search test files for references to affected pages/behaviors. Classify request-mocking-based tests as "mocked UI regression coverage" — not true E2E coverage.
10. **Information architecture (Section 11)**: If the feature adds UI, verify: (a) the spec's navigation placement matches the actual page structure (read the relevant page/layout files), (b) labels in the spec match existing terminology (grep for similar labels), (c) the spec defines where new elements sit relative to existing ones.
11. **Tooltips and contextual help (Section 11)**: If the feature adds settings, limits, status indicators, or actions with consequences, verify the spec includes a tooltip inventory. Check the existing codebase for tooltip patterns to confirm the spec's approach matches established patterns.
12. **Enumerated value contracts (Section 8.4)**: If the feature has filters, sort keys, status badges, role labels, or any other field the backend validates against a fixed allowlist, verify the spec enumerates the **exact wire values** (not just user-facing labels) for each field AND cites the backend source-of-truth file (enum, `frozenset`, `Literal[...]`, regex pattern, or DB CHECK constraint). Grep the cited file to confirm every value is real and every real value is listed. If the spec contains plausible-sounding values without a source citation, flag it as a **High** severity finding — frontend option lists generated from unsourced spec values will drift and produce validation errors in production.

Record every finding in the verification ledger (see below). Fix every inaccuracy found.

### Step 4: Architectural consistency review (Pass 2)

Review the spec for consistency with project architecture:

1. Does the spec respect all "Absolute Rules" from `<conventions_doc>`?
2. Does the data model follow conventions (tenant_id scoping if applicable, repo layer pattern, etc.)?
3. Does the API design follow conventions (auth patterns, error shapes, router structure)?
4. Are service layer patterns correct (job_run lifecycle, execution_id propagation, quota checks, etc.)?
5. Are migration requirements complete (downgrade, idempotency guards)?
6. Does the test strategy cover all required layers per project conventions?
7. **Invariant write-path audit**: For every new invariant stated in the spec, grep for ALL existing code paths that write the related fields. If existing write paths would violate the new invariant after deploy, the spec must either: (a) include updating those write paths in scope, or (b) weaken the invariant to account for legacy behavior.
8. **Cross-feature dependencies**: If the spec references columns, tables, or behavior introduced by another planned feature, classify the dependency as **hard** (blocks implementation) or **soft** (works without, value reduced). Check the confirmed build order.
9. **Audit-event instrumentation** (only if your project has an audit-log table). For every endpoint or service function the spec adds or modifies that mutates state: the spec MUST populate the §6 "Audit-event instrumentation matrix" — choosing an event type, deciding visibility, specifying metadata fields, ensuring atomic emission within the primary transaction. Forbidden in metadata: credentials, tokens, PII beyond display-name strings.

Record every finding in the verification ledger. Fix any inconsistencies.

### Step 5: Input/spec reconciliation

Compare the input document ($ARGUMENTS) against the generated spec:

1. Does the input document scope features that the spec marks as out-of-scope? If so, update the input document to match (or flag the scope decision as an open question).
2. Does the input document use specific model names, cost figures, or technical details that the spec has corrected? Update for consistency.
3. Are there claims in the input document that the codebase audit disproved? Update or annotate them.

The input document and spec must not contradict each other — the input is the "brief," the spec is the "contract."

### Step 6: Cross-model review

This step is **mandatory** when a cross-model reviewer is configured (`<secondary_model>` set in `PROJECT_CONFIG.md`). The cross-model value comes from using a different model family — not a different instance of the same model.

**API key resolution:**
- Parse `<secondary_api_key_envvar>` from `<secondary_api_key_source>` (typically `.env`).
- Use it in API calls per the snippet in `PROJECT_CONFIG.md`.
- Do NOT assume the env var is sourced into the shell — read it explicitly from the configured source.

**API call mechanism:**
Use a Python script (via the Bash tool) or curl to call `<secondary_api_base>`. Send the spec text as the user message, with review instructions in the system message. Request structured JSON output for findings.

**Important API notes:**
- Use the exact model ID `<secondary_model>`. Don't substitute or downgrade.
- Pin `<secondary_api_token_param>` correctly — different APIs disagree on `max_tokens` vs `max_completion_tokens`.

**Fallback if the cross-model reviewer is unavailable:**
- If the API key is missing: alert the user and proceed with primary-model-only review.
- If the API call fails (auth error, timeout, model not available): log the failure, alert the user, and proceed with primary-model-only internal review passes. Do NOT silently skip the step — the user must be informed.
- If the user explicitly opts out: proceed without it, but note in the review log that cross-model review was skipped by user request.

**Reviewer roles** (both fulfilled by the secondary model):

The secondary model reviews in two labeled passes within a single prompt (or two separate calls):

| Role | Focus areas |
|---|---|
| **Pass A: Contract & Data** | API endpoint shapes, auth patterns, error envelopes, data model accuracy, column existence, return type annotations, cross-feature dependencies |
| **Pass B: Impact & Coverage** | Downstream field consumers, test coverage claims (real vs mocked), UX flow completeness, rollout risk, invariant write-path coverage, input/spec scope drift |

**Review protocol:**

1. Send the full spec text to the secondary model with both role focus areas. Request findings as structured output: claim, evidence (file:line), severity (High/Medium/Low), reviewer pass (A or B).

   **On cycle 2 and later — include the rejection log from earlier cycles in the system prompt**, structured as:

   ```
   ## Previously rejected findings (do NOT re-raise without new information)

   The following findings were raised in prior cycles and rejected by the primary model with
   cited counter-evidence. Unless you have *new* evidence that materially changes
   the analysis, omit these from your cycle-N response:

   - Cycle 1 finding #{N}: "{short quote of the claim}"
     Rejection: {one-line counter-evidence, with file:line}
   ...

   You may re-raise a listed finding ONLY if you have new information (a code
   change since last cycle, a corrected citation, a genuinely different angle).
   If you re-raise, state the new information explicitly in the `finding` field.
   "Disagreeing with the rejection" is not new information.
   ```

   This prunes repeat findings. A repeats-only response in cycle N is valid — the convergence stop rule (Step 7) treats it as a clean pass without forcing another cycle.

2. **Primary-model adjudication:** For each finding, the primary model must do one of:
   - **Accept** — cite the evidence, stage the correction for the findings gate (Step 8). Log in the verification ledger.
   - **Reject** — cite counter-evidence from the codebase (file:line) that disproves the finding. Log the rejection with the counter-evidence.
   - **Escalate** — if evidence is ambiguous or the finding requires a product decision, flag as an open question for the user.

3. Rejections without cited counter-evidence are not allowed. "I disagree" is not sufficient — show the code.

**Important:** Accepted corrections are **staged, not applied immediately**. Major accepted corrections require user approval at the findings gate (Step 8) before being written. Minor accepted corrections may be applied without gating.

### Step 7: Cross-model convergence loop

After the primary model adjudicates findings, determine whether another review cycle is needed:

**Re-review trigger:** If any accepted correction changed a **major** element (API contract, data model, auth pattern, error shape, invariant, acceptance criteria, or cross-feature dependency), send the corrected spec back to the secondary model for a fresh review pass. Apply minor corrections before re-submitting.

**Cross-model loop stop rules:**
- **Stop** when the secondary reports no new High-severity findings AND the primary has no unresolved accepted changes.
- **Stop** when the secondary returns only findings the primary has already rejected with cited counter-evidence in a previous cycle (no new information).
- **Stop** after a maximum of 3 cycles. If convergence is not reached by cycle 3, present the remaining disagreements to the user for resolution.

**Internal convergence (primary-model-only):** After the cross-model loop completes, the primary model may run additional internal review passes (Steps 3–4) if needed:
- If two consecutive primary-only passes produce only wording or formatting edits, stop.
- Maximum 2 additional primary-only passes after the cross-model loop.

**Convergence criteria** (applies to both cross-model and internal passes): A pass is "clean" if it produces no changes to:
- Table/column definitions
- API endpoint definitions or response shapes
- Domain rules or state transitions
- Security or authorization model
- Acceptance criteria
- Required invariants or their write-path coverage

### Step 8: Findings gate

Before writing any files, classify all staged findings into:

- **Major** (High severity): Changes to API contracts, data model, auth patterns, error shapes, invariants, acceptance criteria, or cross-feature dependencies. These change what gets built.
- **Minor** (Medium/Low severity): Wording, formatting, documentation consistency, cost estimates, non-functional details. These improve clarity but don't change the implementation contract.

**Gate rules:**
- **Major findings**: Present to the user for confirmation before applying. List each finding with its source (primary internal or secondary Pass A/B) and the proposed correction. Do not write files until the user approves.
- **Minor findings**: May be applied without explicit confirmation, but include them in the review log so the user can see what changed.
- If there are no major findings, proceed directly to writing.

### Step 9: Write the spec

Write the final spec to the appropriate location:
- Default: same directory as the input idea, named `feature_spec.md`
- Ask the user if they have a preferred location/filename

### Step 10: Track deferred phases

**This step is MANDATORY when the spec defines multiple phases.** Deferred phases contain scoped, reviewed work that will be lost if not explicitly tracked.

1. Read the spec's "Phase boundaries" section. List every phase beyond Phase 1 with its FRs.
2. For each deferred phase, check whether a tracking file already exists (`glob` for `*idea*.md` or `*phase*_idea.md` in the feature directory).
3. If no tracking file exists, create one at `<planned_features_root>/<feature_dir>/phase<N>_idea.md` following the idea template. Include:
   - Origin pointer to the spec file and line numbers where the deferred FRs are defined
   - The deferred FRs with enough context to generate a future implementation plan
   - Why the work was deferred (from the spec's phase boundary rationale)
   - Dependencies on the earlier phase(s)
4. Commit the tracking file with the spec.

**Why this matters:** Spec phase boundaries represent reviewed, scoped work. Without an explicit tracking artifact, deferred phases exist only as prose inside the spec and are effectively invisible to future planning sessions.

### Step 11: Update project docs

Evaluate whether these files need updates based on the new spec:

- `<state_doc>` — if this feature changes priorities or adds planned work
- `<arch_doc>` — if this feature introduces new services, data flows, or integrations
- `<conventions_doc>` — if this feature adds new conventions, rules, or environment variables

Present proposed doc updates to the user for approval before writing.

### Step 12: Update pipeline status

**This step is MANDATORY in Generate mode.** Write or update a `pipeline_status.md` file in the feature directory to record the spec stage completion. This file enables the `/pipeline` orchestrator to detect what stage a feature is at and resume automatically.

Write to `<planned_features_root>/<feature_dir>/pipeline_status.md`:

```markdown
# Pipeline Status — <Feature Name>

## Idea
- Status: Complete
- File: idea.md

## Spec
- Status: Approved
- Date: <YYYY-MM-DD>
- File: feature_spec.md
- Cross-model review: <secondary_model> passed (<N> cycles)
- Phases: <N total, N covered by spec>

## Plan
- Status: Not started

## Implementation
- Status: Not started
```

If `pipeline_status.md` already exists, update only the `## Spec` section — do not overwrite other sections.

---

## Workflow — Review mode

When reviewing an existing spec (not generating a new one):

1. **Gather context**: Read `<conventions_doc>`, `<arch_doc>`, `<state_doc>`, and the spec at $ARGUMENTS.
2. **Run Pass 1 and Pass 2** (Steps 3–4 above) against the existing spec.
3. **Build the verification ledger** for every material claim.
4. **Deferred phase audit**: If the spec defines multiple phases, check whether each deferred phase has a tracking artifact. Report any untracked deferred phases as a **Medium** finding.
5. **Cross-model review (optional but recommended):** If the secondary model is available, send the spec for external review using the same protocol as Generate mode Step 6.
6. **Return findings only.** Do not rewrite the spec. Present findings as:
   - Severity (High / Medium / Low)
   - Source (primary internal / secondary Pass A / secondary Pass B)
   - Location (file:line)
   - What the spec claims vs. what the codebase shows
   - Suggested correction (if straightforward)
7. **Flag open questions** that need the user's input to resolve.

---

## Workflow — Reconcile mode

When reconciling an input brief against an existing spec:

1. **Read both documents** and the project context files.
2. **Diff scope**: List every capability the input promises that the spec marks out-of-scope (and vice versa).
3. **Diff technical claims**: List every technical detail (model names, cost figures, field names, API shapes) where the input and spec disagree.
4. **Deferred phase audit**: If the spec defines multiple phases, check whether each deferred phase has a tracking artifact.
5. **Return the diff** with a recommendation for each mismatch: update input, update spec, create tracking file, or flag as open question.

---

## Workflow — Review & Patch mode

When the user provides findings or explicitly asks to fix/correct an existing spec:

1. **Gather context**: Read `<conventions_doc>`, `<arch_doc>`, `<state_doc>`, and the spec at $ARGUMENTS.
2. **Verify each finding** against the codebase. For each:
   - Read the referenced code to confirm the finding is accurate.
   - Record in the verification ledger as Verified, Partially Correct, or Incorrect.
   - If incorrect, cite counter-evidence (file:line).
3. **Classify findings** into Major and Minor (see Findings gate in Generate mode).
4. **Present Major findings** to the user with proposed corrections. Wait for approval.
5. **Apply approved corrections** to the spec file. Apply Minor corrections without gating.
6. **Run a single verification pass** on the patched spec to confirm corrections didn't introduce new issues.
7. **Update the input document** if corrections affect scope, technical claims, or cost figures that the input also states.
8. **Return the verification ledger** and a summary of what was changed.

---

## Output format

The spec must follow the template structure exactly. Every section must be filled in — use "N/A" with a brief reason only if a section genuinely does not apply.

## Verification ledger

For every material claim in the spec (API shapes, column existence, auth patterns, function behavior, test coverage, error shapes), maintain a ledger:

| Claim | Verified by | Status |
|---|---|---|
| `<table>.<column>` is `<type>`, nullable | Read `<file>:XX` | Verified |
| `create_X()` prevents non-null overwrites | Read `<file>:36-49` — only guards `None` | **Corrected** — spec updated |
| `<test_file>` provides live-X E2E coverage | Read file — uses request mocking | **Corrected** — reclassified as mocked UI debt |

Include the ledger in the review log output. This makes the review trustworthy and auditable.

## Common pitfalls to avoid

These are patterns that have caused spec inaccuracies in the past. Check for each one:

1. **Error shapes assumed globally** — verify per-route by reading the handler and any contract test, not by assuming one global envelope.
2. **Assuming auth mechanism** — read the actual route's dependency chain. Don't guess.
3. **Claiming repo-layer guards that don't exist** — read the function body to confirm. The guard may only cover specific values, not all overwrites.
4. **Missing downstream field consumers** — search for every place a field is read, not just where it's written.
5. **Citing mocked tests as E2E coverage** — any request mocking in E2E tests is mocked UI regression coverage, not true end-to-end coverage.
6. **Response shape mismatch (object vs array)** — check the route's return type annotation.
7. **Hardcoded third-party model names** — always reference the abstraction your project uses, not a specific model.
8. **Unstated invariant violations** — when adding a new invariant, trace every existing write path.
9. **Input doc / spec scope drift** — the input doc may promise features the spec marks out-of-scope. Reconcile before finalizing.
10. **Invented enum / filter / dropdown values** — specs that name filter options, sort keys, status badge variants, tier labels, or any other field the backend validates against a fixed allowlist MUST cite the backend source-of-truth file. If a value appears in the spec without a grep target, assume it was invented.

## Review log

At the end, provide a summary:
- Mode used (Generate / Review / Reconcile / Review & Patch)
- Number of review passes performed
- Verification ledger (material claims checked)
- Key inaccuracies found and corrected (or reported, in Review mode)
- Any open questions that need user input
- Proposed doc updates (if any)
