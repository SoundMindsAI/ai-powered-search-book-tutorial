---
name: pipeline
pipeline-stage: 0
pipeline-role: orchestrator
description: "Orchestrate the full feature development pipeline from idea to merged PR. Detects current stage, invokes the next skill (spec-gen, impl-plan-gen, impl-execute), and pauses for approval between stages. Use when: running a feature end-to-end, resuming a feature pipeline, checking pipeline status, or advancing a feature to the next stage. Trigger phrases: run pipeline, advance feature, pipeline status, idea to done, full pipeline, resume pipeline."
argument-hint: "status | <path to feature directory> [--auto] [--from <stage>] [--to <stage>] [--status]"
allowed-tools: Read, Glob, Grep, Bash, Write, Edit, Agent, WebFetch, WebSearch, TodoWrite
user-invocable: true
---

# Feature Pipeline Orchestrator

You orchestrate the full feature development pipeline. You do **not** duplicate the logic of individual skills — you detect the current stage of a feature, invoke the appropriate skill, pause for user approval, and advance to the next stage.

> Before doing anything else, read `PROJECT_CONFIG.md` at the repo root. Every `<placeholder>` in this skill resolves from there.

## Pipeline stages

```
  idea.md ──▶ /spec-gen ──▶ /impl-plan-gen ──▶ /impl-execute ──▶ deployed
     1            2               3                  4              5
   IDEA         SPEC            PLAN           IMPLEMENT        DONE
```

Each stage produces artifacts and requires approval before advancing:

| Stage | Input artifact | Skill invoked | Output artifact | Approval gate |
|-------|---------------|---------------|-----------------|---------------|
| **IDEA** | `idea.md` | — | — | Idea exists and is ready for spec |
| **SPEC** | `idea.md` | `/spec-gen` | `feature_spec.md` | User approves spec |
| **PLAN** | `feature_spec.md` | `/impl-plan-gen` | `implementation_plan.md` | User approves plan |
| **IMPLEMENT** | `implementation_plan.md` | `/impl-execute --all` | Code + PR + CI green | Phase gates + final review pass |
| **DONE** | PR merged | — | — | Deploy verified (if applicable) |

If your project has a tenant-facing UI, `/guide-gen` may be invoked from inside `/impl-execute` post-implementation — the orchestrator does not invoke `/guide-gen` directly.

## Inputs

`$ARGUMENTS` is one of:

- **`status`** (or empty) — **Project-wide status mode.** Enumerate every feature under `<planned_features_root>`, sort by dependency-derived priority order, and render a status table with a single explicit "Next action" line. No skills are invoked. See [Project-wide status mode](#project-wide-status-mode) below.
- **`<path to feature directory>`** — Single-feature mode. Detect the current stage and advance it. Path must be under `<planned_features_root>`.
- **Optional flags** (appended after the path; ignored in `status` mode):
  - `--auto` — **Autonomous mode.** Run the entire pipeline (idea → spec → plan → implement → PR) without pausing for inter-stage approval. Cross-model review, verification gates, and test suites still run within each skill — those are hard gates, not skippable. In epic mode, `--auto` pauses only between features. See "Autonomous mode" below.
  - `--from <stage>` — Force start from a specific stage (`idea`, `spec`, `plan`, `implement`). Overrides auto-detection.
  - `--to <stage>` — Stop after completing a specific stage. Useful for generating just the spec or just the plan.
  - `--status` — Report current single-feature status without advancing. No skills invoked.

## Stage detection

On invocation, detect the current stage by examining the feature directory:

```
1. Read pipeline_status.md if it exists — this is the authoritative source.
2. If no pipeline_status.md, infer from artifacts:
   a. implementation_plan.md exists AND has execution tracker with completed stories → IMPLEMENT (in progress or done)
   b. implementation_plan.md exists → PLAN complete, ready for IMPLEMENT
   c. feature_spec.md exists → SPEC complete, ready for PLAN
   d. idea.md exists → IDEA complete, ready for SPEC
   e. Nothing exists → ERROR: no idea.md found
```

`pipeline_status.md` may not exist for features created before this orchestrator was added. Fall back to artifact detection gracefully.

### Status report format

When `--status` is passed or when reporting status before advancing:

```
Pipeline Status: <Feature Name>
Directory: <path>

  [x] Idea        idea.md
  [x] Spec        feature_spec.md (approved YYYY-MM-DD, N review cycles)
  [ ] Plan        Not started
  [ ] Implement   Not started
  [ ] Done        —

Next action: Generate implementation plan from approved spec
Command: /impl-plan-gen <path>/feature_spec.md
```

## Project-wide status mode

When `$ARGUMENTS` is the literal string `status` (or empty), render a project-wide pipeline status across **all** features in `<planned_features_root>`. **Do not invoke any skills in this mode.** The user is asking "where are we and what's next" — give them an unambiguous answer.

**The output MUST be ordered by dependency-derived priority.** Never sort by `ls`, alphabet, or directory mtime — the user should not have to guess what comes next.

### Algorithm

1. **Enumerate feature directories.** List `<planned_features_root>`. Exclude `feature_templates/` and any non-feature folders (no `feature_spec.md` and no `idea.md`).

2. **Parse dependencies for each feature.** For each `<feature>/feature_spec.md`:
   - Read the first ~20 lines.
   - Look for a `Depends on:` line (typically in the metadata block, e.g. `- Depends on: [\`infra_bootstrap\`](...)`).
   - Extract the referenced feature folder names. Treat phrases like "ALL prior backend features" or "ALL prior features" as a transitive dependency on every relevant prior feature.
   - If the spec has no `Depends on:` line, treat it as a root.
   - If only `idea.md` exists (no spec), parse `idea.md` the same way; if neither exists, list under "Unparseable" at the bottom.

3. **Topologically sort.** Standard Kahn's algorithm:
   - Roots come first.
   - Tiebreaker among same-tier features: prefix order `infra_` → `feat_` → `chore_` → `bug_`, then alphabetical.
   - If a cycle is detected, list cycle members at the bottom under "Cycle detected — review these specs" and continue with the rest.

4. **Cross-check against your project's canonical priority list** (e.g., a roadmap doc, an epic list, an MVP plan) **if one exists**. Compare to the dep-derived order:
   - **If they match:** present the priority order without comment.
   - **If they disagree:** present the dep-derived order (it's machine-verifiable) and add a single line below the table flagging the disagreement.

5. **Detect each feature's current stage** from artifacts:
   - Folder exists in `<implemented_features_root>` for this slug AND no `phase*_idea.md` remains in the planned-features folder → **DONE**.
   - `implementation_plan.md` exists with completed stories in tracker AND a `phase*_idea.md` file remains alongside → **PARTIAL (Phase N done, Phase N+1 pending)**. The "Next action" for a partial feature is `/pipeline <feature>/phase<N+1>_idea.md` so a fresh spec/plan loop starts on the deferred phase.
   - `implementation_plan.md` exists with completed stories → **IMPLEMENT (in progress)**.
   - `implementation_plan.md` exists, no completed stories → **PLAN complete, ready for IMPLEMENT**.
   - `feature_spec.md` exists, no plan → **SPEC complete, ready for PLAN**.
   - `idea.md` exists only → **IDEA complete, ready for SPEC**.
   - Folder exists with no artifacts → **EMPTY**.

6. **Pick the "Next action."** First feature in priority order whose stage is not DONE. For PARTIAL features, the next action targets the deferred phase's `phase*_idea.md`. Quote the exact `/pipeline <path>` command.

### Required output format

```
Pipeline Status — Priority Order

| #  | Feature                | Depends on | Idea | Spec | Plan | Implement | Done |
|----|------------------------|-----------|------|------|------|-----------|------|
| 1  | infra_bootstrap        | —         |  —   |  ✓   |  —   |    —      |  —   |
| 2  | infra_auth             | 1         |  —   |  ✓   |  —   |    —      |  —   |
| ...                                                                                |

**Next action: advance #<n> `<feature>` from <STAGE> → <NEXT STAGE>.**

```
/pipeline <planned_features_root>/<feature>
```

Implemented: <count> · Planned: <count>
```

- The `Depends on` column shows the **`#`** of each upstream feature, not the full slug, to keep the table tight. Use `—` for roots.
- Use `✓` for completed stages, `—` for not-started, `…` for in-progress.
- File-link each feature name to its `feature_spec.md` so the user can click through.
- The "Next action" line is mandatory and must contain exactly one feature, one stage transition, and one runnable command.

### Why this matters

A status table sorted by `ls` forces the user to mentally walk the dependency graph; a priority-sorted table with a single "Next action" line does that work for them.

## Workflow

### Step 0: Branch on `status` vs. feature path

If `$ARGUMENTS` is `status` (or empty), execute "Project-wide status mode" and return. Do not proceed.

Otherwise (a feature path was provided), continue to Step 1.

### Step 1: Read context and detect stage

1. Read `<conventions_doc>` (e.g., `CLAUDE.md`, `AGENTS.md`), `<arch_doc>`, `<state_doc>` for project context.
2. List the feature directory contents.
3. Read `pipeline_status.md` if it exists.
4. If no `pipeline_status.md`, check for `idea.md`, `feature_spec.md`, `implementation_plan.md`.
5. Determine the current stage and the next stage to execute.
6. Apply `--from` override if provided.
7. Apply `--to` limit if provided.
8. Report current status to the user.

### Step 2: Confirm advancement

**In `--auto` mode:** Skip this step entirely. Report what's about to happen (one line per stage), then begin executing immediately.

**In interactive mode (default):** Before invoking any skill, confirm with the user:

> **Pipeline will advance to: SPEC stage**
> - Input: `idea.md` (summarize the idea in 1-2 sentences)
> - Skill: `/spec-gen <path>/idea.md`
> - This will generate a feature spec with cross-model review.
> - Estimated scope: <brief based on idea complexity>
>
> Proceed?

If the user has already indicated they want to run the full pipeline (e.g., "run the full pipeline"), treat that as blanket approval to advance through stages — but still pause at each approval gate to let the user review the output.

### Step 3: Execute stages sequentially

For each stage from current to target:

#### Stage: IDEA → SPEC

1. Verify `idea.md` exists and read it.
2. Invoke `/spec-gen <feature_dir>/idea.md`.
3. Spec-gen will:
   - Generate the spec from the idea
   - Run primary-model verification passes
   - Run cross-model review (max 3 cycles)
   - Present major findings for approval
   - Write `feature_spec.md`
   - Write `pipeline_status.md` with spec stage marked complete
4. **Approval gate:**
   - **`--auto` mode:** Log a brief summary (FR count, phase count, review cycle count). Proceed immediately.
   - **Interactive mode:** Present the spec.
     > "Spec generated at `<path>/feature_spec.md`. Review the spec — particularly the API contracts (§8), data model (§9), and acceptance criteria (§12). Approve to continue to implementation plan, or request changes."
5. If the user requests changes (interactive only), re-invoke `/spec-gen <path>/feature_spec.md` in Review & Patch mode.
6. On approval (or auto-advance), proceed to next stage.

#### Stage: SPEC → PLAN

1. Verify `feature_spec.md` exists and read it.
2. Invoke `/impl-plan-gen <feature_dir>/feature_spec.md`.
3. Impl-plan-gen will:
   - Generate the plan from the spec
   - Verify spec ↔ plan FR traceability
   - Run cross-model review (max 3 cycles)
   - Present major findings for approval
   - Write `implementation_plan.md`
   - Update `pipeline_status.md`
4. **Approval gate:**
   - **`--auto` mode:** Log a brief summary (story count, epic count, test layer coverage, review cycle count). Proceed immediately.
   - **Interactive mode:** Present the plan.
     > "Plan generated at `<path>/implementation_plan.md`. Review the stories, endpoints, and key interfaces. The plan covers <N stories across M epics>. Approve to begin implementation, or request changes."
5. If the user requests changes (interactive only), re-invoke `/impl-plan-gen <path>/implementation_plan.md` in Review & Patch mode.
6. On approval (or auto-advance), proceed to next stage.

#### Stage: PLAN → IMPLEMENT

1. Verify `implementation_plan.md` exists and read it.
2. Create a feature branch if not already on one (**never commit to `<default_branch>`**).
   - Branch naming: `<feature_branch_prefix><feature-dir-slug>`.
   - If already on a feature branch, continue on it.
3. Invoke `/impl-execute <feature_dir>/implementation_plan.md --all`.
4. Impl-execute will:
   - Execute stories sequentially with verification gates
   - Run phase gate cross-model reviews
   - Run test coverage audit
   - Extract deferred work
   - Update documentation
   - Assess guide impact (and optionally run `/guide-gen`)
   - Push and create PR
   - Monitor CI
   - Adjudicate automated reviewer comments
   - Run final cross-model review
5. **Approval gate:**
   - **`--auto` mode:** Report results (PR URL, CI status, test counts, review status). This is the end of autonomous execution for this feature — the user must merge the PR manually.
   - **Interactive mode:** Report results.
6. **Finalize after CI + automated review pass** (impl-execute Step 8):
   - Verify all stories complete
   - Update `pipeline_status.md` to `Implementation: Complete`
   - Update `implementation_plan.md` status to `Complete (PR #<N>)`
   - Update `<state_doc>`
   - **Check for `phase*_idea.md` files** — if any exist, STOP and ask the user for instructions
   - Move feature folder: `<planned_features_root>/<dir>` → `<implemented_features_root>/<YYYY_MM_DD>_<short_name>/`
   - Commit and push the finalization changes (on a separate `docs/finalize-<slug>` branch off the default — the feature branch is already merged)

#### Stage: IMPLEMENT → DONE

This stage is manual — the user merges the PR and verifies any deploy. The orchestrator can help monitor:

1. If the user says "merged":
   - Check deploy status with the project's CI tool.
   - Verify health endpoints if applicable.
2. Update `pipeline_status.md`:
   ```
   ## Done
   - Status: Deployed
   - Date: <YYYY-MM-DD>
   - PR: #<number>
   - Release: <tag if applicable>
   ```

### Step 4: Report completion

After reaching the target stage (or DONE):

```
Pipeline Complete: <Feature Name>

  [x] Idea        idea.md
  [x] Spec        feature_spec.md (approved, N review cycles)
  [x] Plan        implementation_plan.md (approved, N review cycles)
  [x] Implement   PR #XX merged, CI green, N stories, M tests
  [x] Done        Deployed YYYY-MM-DD

Deferred work: phase2_idea.md (if applicable)
```

---

## Resuming a pipeline

When invoked on a feature that's mid-pipeline:

1. Detect the current stage (Step 1).
2. If a stage is in progress (e.g., impl-execute was interrupted):
   - For IMPLEMENT: invoke `/impl-execute <plan> <next-story-id>` to resume from the next incomplete story.
   - For SPEC or PLAN: re-invoke the skill — it will detect the existing file and enter Review mode.
3. If a stage is complete but the next hasn't started, advance normally.

---

## Multi-feature pipeline (epic mode)

When the feature directory contains multiple sub-features (e.g., an epic with numbered phases):

1. The user invokes the pipeline on the parent epic, not individual children.
2. The orchestrator identifies each child directory. Two layouts are supported:
   - **Flat siblings** with an epic prefix.
   - **Nested layout** where the epic is a parent folder containing numbered child phase folders (e.g., `epic_<name>/phase_01_<x>/`). Glob one level deeper into the parent folder and enumerate only child directories whose basename matches `phase_[0-9][0-9]_*`; sort lexicographically. Ignore `README.md`, `deferred_*` folders, and any non-`phase_XX_*` planning material at the epic root.
3. Process features **sequentially** in numbered order — each child goes through the full pipeline before the next starts.
4. Respect dependencies: if phase 02 depends on phase 01, ensure 01's PR is merged before starting 02.
5. Report aggregate status across the epic.

**Interactive mode:** Process one child at a time; pause for approval between children. The user can say "continue to the next phase" to advance.

**`--auto` mode:** Run each child end-to-end autonomously, then **pause between children**. This is the only pause point in `--auto` mode. The user must:
1. Review and merge the PR for the completed child.
2. Confirm any deploy succeeded.
3. Say "continue" to start the next child.

This ensures dependent children don't start on stale code.

---

## Autonomous mode (`--auto`)

When `--auto` is passed, the pipeline runs the full lifecycle for each feature without pausing for inter-stage approval. This is the intended mode for running an epic end-to-end.

### What still runs (hard gates — never skipped)

| Gate | Skill | What happens |
|------|-------|-------------|
| Primary-model verification passes | spec-gen | Codebase accuracy + architectural consistency |
| Cross-model review (max 3 cycles) | spec-gen | Contract, data model, impact, coverage |
| Primary-model convergence loop | spec-gen | Internal review until clean |
| Primary-model verification passes | impl-plan-gen | Plan-internal consistency + codebase accuracy |
| Cross-model review (max 3 cycles) | impl-plan-gen | Structural, contract, implementation, risk |
| Story verification gates (`<lint>`, `<typecheck>`, `<tests>`) | impl-execute | Per-story quality gate |
| Phase gate cross-model review | impl-execute | Per-phase cumulative diff review |
| Test coverage audit | impl-execute | All planned test files must exist |
| Final cross-model review | impl-execute | Complete PR diff review |
| CI pipeline | impl-execute | CI must pass |
| Automated reviewer adjudication | impl-execute | Bot review comments addressed |

### What's skipped (inter-stage pauses only)

| Skipped | Why it's safe |
|---------|---------------|
| "Approve spec to continue?" pause | Cross-model review already audited with max 3 convergence cycles |
| "Approve plan to continue?" pause | Cross-model review already audited with max 3 convergence cycles |
| "Approve implementation to merge?" pause | PR is created but NOT merged — user still merges manually |

### When `--auto` stops (escalation triggers)

Even in `--auto` mode, the pipeline **stops and escalates** when:

1. **Verification gate failure** — `<lint>`, `<typecheck>`, or test failure that can't be auto-fixed.
2. **Cross-model review produces unresolved High-severity findings after 3 cycles** — convergence not reached.
3. **CI failure** — CI workflow fails.
4. **Manual configuration required** — third-party app registration, DNS changes, deployment env vars, etc.
5. **Missing prerequisites** — `idea.md` doesn't exist, spec has unresolved open questions.
6. **Dependency not met (epic mode)** — prior child's PR hasn't been merged.

On escalation, the pipeline reports what happened, what needs to be resolved, and how to resume (`/pipeline <dir> --auto --from <stage>`).

---

## Error handling

### Skill failure

If a skill fails:
1. Report what failed and why.
2. Do NOT advance to the next stage.
3. Suggest remediation.
4. The pipeline can be resumed after the issue is resolved.

### Missing artifacts

If expected artifacts are missing:
1. Report the gap.
2. Offer to start from the appropriate earlier stage.

### Branch conflicts

If the feature branch already exists or has diverged:
1. Check the branch state before creating a new one.
2. If a branch exists with work from a previous pipeline run, offer to continue on it or create a fresh branch.

---

## Rules

1. **Never duplicate skill logic.** The orchestrator invokes skills — it does not re-implement spec generation, plan generation, or story execution.
2. **Never skip approval gates in interactive mode.** Each stage completion requires user acknowledgment before advancing. In `--auto` mode, inter-stage pauses are skipped but all quality gates within skills still fire. Auto mode still pauses between children in an epic.
3. **Never commit to the default branch.** Feature branches only.
4. **Always report status before advancing.** The user must know what stage they're at and what's about to happen.
5. **Always use the correct skill.** spec-gen for specs, impl-plan-gen for plans, impl-execute for implementation. Never substitute.
6. **Respect `--to` limits.** If the user says `--to plan`, stop after plan approval — do not start implementation.
7. **Track progress in pipeline_status.md.** Update it at each stage transition so future conversations can resume.
8. **Handle missing pipeline_status.md gracefully.** Many features pre-date this orchestrator — fall back to artifact detection.
9. **One feature at a time.** In epic mode, complete one child's full pipeline before starting the next.
10. **Inform the user at every transition.** What just completed, what's next, what they need to review.
11. **Project-wide status output is always priority-ordered with one explicit "Next action."** Never sort by directory listing, alphabet, or recency. End the output with a single bold "Next action:" line and the exact `/pipeline <path>` command to run.
