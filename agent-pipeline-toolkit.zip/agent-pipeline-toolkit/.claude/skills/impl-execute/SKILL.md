---
name: impl-execute
pipeline-stage: 3
pipeline-role: implementation_plan.md → code + PR + CI
description: "Execute implementation plans story-by-story with enforced verification gates, cross-model code review, and progress tracking. Use when: implementing stories from an approved plan, executing a plan step by step, running a story with verification, or resuming implementation. Also supports an ad-hoc ship mode for small bug fixes / refactors that don't warrant /pipeline scaffolding. Trigger phrases: execute implementation plan, implement story, run story, execute plan, resume implementation, implement next story, execute all stories, ship this change, take this through review."
argument-hint: "[path to implementation_plan.md] [optional: story ID like '1.1' | '--all' for batch mode] | --ad-hoc (no plan; ship pending changes through review/merge ceremony)"
allowed-tools: Read, Glob, Grep, Bash, Write, Edit, Agent, WebFetch, WebSearch, TodoWrite
user-invocable: true
---

# Implementation Plan Executor

You execute implementation plans. Every story follows a prescribed workflow with mandatory verification gates. Code quality is enforced by lint/typecheck/test gates and cross-model code review.

> Read `PROJECT_CONFIG.md` at the repo root before starting. Every `<placeholder>` resolves from there.

## Inputs

- **Implementation plan path:** The path to the approved `implementation_plan.md` (omit when invoked with `--ad-hoc`).
- **Optional second argument:**
  - Story ID (e.g., `1.1`) — start at or resume from a specific story.
  - `--all` — batch mode: execute all remaining incomplete stories automatically.
  - Omitted — interactive mode: execute the next incomplete story, then pause for user direction.
- **Ad-hoc mode:** invoke as `/impl-execute --ad-hoc` with no plan path. Requires changes already committed on a feature branch (the skill ships them through the standard review/merge ceremony — no story execution).
- **Project context:** `<conventions_doc>`, `<arch_doc>`, `<state_doc>` (read before starting).

## Execution modes

| Mode | Invocation | Behavior |
|---|---|---|
| **Interactive** (default) | `/impl-execute path/to/plan.md` | Execute next incomplete story, report results, wait for user. |
| **Resume** | `/impl-execute path/to/plan.md 2.1` | Start at story 2.1, then pause after completion. |
| **Batch** | `/impl-execute path/to/plan.md --all` | Execute all remaining stories sequentially. Run phase gates between phases. Escalate to user ONLY on gate failures, manual steps, or ambiguous decisions. |
| **Ad-hoc** | `/impl-execute --ad-hoc` | No plan, no story execution. Runs ONLY the post-implementation ceremony against changes already committed to the current feature branch. See "Ad-hoc mode behavior" below. |

### Batch mode behavior

In batch mode, the executor loops through all incomplete stories:

```
for each incomplete story:
    1. Execute the story (Steps 1-8 from story execution workflow)
    2. If verification gate fails → STOP, escalate to user
    3. If story requires manual steps → STOP, guide user, wait for confirmation
    4. If all stories in a phase are now complete → run phase gate
    5. If phase gate fails → STOP, escalate to user
    6. Continue to next story

after all stories complete:
    1. Run test coverage audit (compare plan's testing workstream against written tests)
    2. Seed the post-implementation TodoWrite with ALL of these items (NOT optional — every
       item must be tracked before any post-impl work begins, so none are implicitly skipped):
          - Extract deferred work (Step 1)
          - Documentation updates (Step 2)
          - Tangential observations sweep (Step 2.5) — BLOCKING
          - Guide impact assessment + guide-gen run (Step 3) — MANDATORY gate (if UI was touched)
          - Push + open PR (Step 4)
          - Monitor CI (Step 5)
          - Adjudicate automated reviewer comments (Step 6)
          - Final cross-model review (Step 7)
          - Finalize: verify completion, move to implemented_features (Step 8)
    3. Run each post-implementation step, marking the todo complete as you go
    4. Run finalization (Step 8)
    5. Report final status to user
```

**Batch mode escalation rules:**
- **Always stop for:** verification gate failure, manual configuration steps, ambiguous implementation decisions, test failures that aren't obviously fixable.
- **Never stop for:** successful story completion, lint auto-fixes, formatting changes, routine progress updates.
- **Progress reporting:** Update TodoWrite after each story. The user can check progress at any time without interrupting execution.

### Ad-hoc mode behavior

Ad-hoc mode (`/impl-execute --ad-hoc`) is for changes that don't warrant `/pipeline` scaffolding: small bug fixes, refactors, automated-reviewer-feedback follow-ups, infra-sweep PRs that combine a few unrelated tiny fixes. Anything where writing a `feature_spec.md` and `implementation_plan.md` would be more ceremony than the change itself.

**Preconditions (skill verifies before running):**
- Current branch is NOT `<default_branch>`. If on the default branch, ad-hoc mode aborts with a prompt to create a feature branch first.
- The branch has at least one commit ahead of `origin/<default_branch>` OR uncommitted-but-staged changes worth shipping. If the working tree is clean and the branch is up to date, abort with "nothing to ship."
- The user has already done the actual code work — ad-hoc mode does not implement; it ships.

**What ad-hoc mode SKIPS** (compared to plan-driven invocation):
- All of "Pre-execution setup" Step 3 (parse plan) and Step 4 (TodoWrite from stories) — there is no plan.
- The entire **Story execution workflow** (Steps 1–8 per story). No story loop runs.
- Post-implementation Step 0b (test coverage audit against the plan).
- Post-implementation Step 1 (extract deferred work from spec phases).
- Post-implementation Step 8 sub-steps that touch plan/pipeline_status/folder-move (no plan, no folder to move).

**What ad-hoc mode KEEPS** (the value of running this skill instead of doing it by hand):
- Pre-execution setup Step 1 (read project context) and Step 2 (check branch state).
- Post-implementation Step 0a (worktree pre-flight — surfaces locked sibling worktrees that would block branch ops later).
- Post-implementation Step 0b.1 (audit-event coverage audit if applicable — small fixes can still introduce new tenant-visible mutations).
- Post-implementation Step 2 (`<state_doc>` update if applicable).
- Post-implementation Step 2.5 (**tangential-observations sweep — BLOCKING**). Bug fixes routinely surface unrelated bugs; capture them as idea files before push.
- Post-implementation Step 3 (guide impact assessment — MANDATORY GATE if frontend was touched).
- Post-implementation Step 4 (push + `<pr_open_command>` with the standard Summary / Test plan template).
- Post-implementation Step 5 (CI watch).
- Post-implementation Step 6 (automated reviewer adjudication with the four-quadrant rubric — this is the highest-value piece for small fixes since drive-by bugs often slip past human review without the discipline).
- Post-implementation Step 7 (**OPTIONAL** — final cross-model review). Default to skipping for changes ≤30 LOC across ≤3 files; require for anything larger or anything touching critical paths.
- Post-implementation Step 9 (post-merge local cleanup).

**Recommended PR-body shape for ad-hoc mode:**

```markdown
## Summary
<what changed and why — 1–3 bullets, plain prose>

## Test plan
- [x] <relevant tests run locally>
- [x] <lint_command> && <typecheck_command>
- [ ] <staging verification if applicable>
```

No "Test coverage" section (no plan to compare against). No "Idea file" section unless one exists for the change.

**When NOT to use ad-hoc mode:**
- The change introduces a new feature surface that future work will extend → use `/pipeline` so a spec exists for the next contributor.
- The change touches >5 files OR >100 LOC of non-test code → use `/pipeline` so phase gates and per-story commits run.
- The change requires a migration → use `/pipeline` so the spec captures the migration's discipline.
- The change introduces or modifies an absolute-rule surface → use `/pipeline` so the spec captures rule compliance explicitly.

If the user invokes `/impl-execute --ad-hoc` for a change that hits any of the above, the skill flags it and asks whether to proceed anyway or fall back to `/pipeline`.

## Pre-execution setup

Before executing the first story:

1. **Read context files** in order:
   - `<conventions_doc>` — project conventions, absolute rules
   - `<arch_doc>` — system design, boundaries
   - `<state_doc>` — current branch, migration head, active priorities
   - The implementation plan at the provided path

2. **Check branch state:**
   - Verify current branch (never commit to `<default_branch>`).
   - If on `<default_branch>`, create a feature branch before proceeding.
   - If a feature branch already exists for this plan, switch to it.
   - Run `git status` to check for uncommitted changes.

3. **Parse the plan:**
   - Identify all stories and their completion status from the execution tracker.
   - Find the first incomplete story (or the story specified by the user).
   - Read the story's full scope: outcome, new/modified files, endpoints, key interfaces, tasks, DoD.

4. **Set up progress tracking:**
   - Use TodoWrite to create a task list from the plan's stories.
   - Mark already-completed stories as done.

---

## Story execution workflow

> **Ad-hoc mode:** skip this entire section. Ad-hoc mode has no stories. Jump directly to "Post-implementation" below, starting at Step 0a (worktree pre-flight).

For each story, execute these steps **in order**. Each step is a hard gate — do not proceed to the next step if the current one fails.

### Step 1: Read and confirm scope

1. Read the story from the implementation plan.
2. List: outcome, new files, modified files, endpoints (if any), key interfaces (if any).
3. Verify modified files still exist at the claimed paths (`glob` each one).
4. If the plan references line numbers, verify they are approximately correct (within ~20 lines).
5. Inform the user which story you are implementing and what it does.

### Step 2: Implement backend changes

Order of operations (backend stories):
1. **Models** — add/modify ORM model columns.
2. **Migration** — create migration if schema changed (using `<migration_create_command>`).
3. **Repo** — add/modify repository functions.
4. **Domain** — add/modify pure domain logic.
5. **Service** — add/modify service layer functions.
6. **Router/Schemas** — add/modify API endpoints and schemas.
7. **Config** — add settings fields, update `.env.example` or your project's equivalent.

For each file change:
- Read the file first (never edit without reading).
- Make the minimal change described in the story.
- Do not add features, refactors, or improvements beyond the story scope.

### Step 3: Backend verification gate

**All of these must pass before proceeding.** If any fail, fix the issue and re-run.

```bash
<format_command>                # auto-fix any drift FIRST so subsequent checks see canonical form
<lint_command>
<typecheck_command>
<format_check_command>          # CI parity — this must agree with what CI runs
```

Then run the targeted test layer:
```bash
<unit_test_command>             # always
<integration_test_command>      # if story touches DB, services, or endpoints
<contract_test_command>         # if story adds/modifies endpoints
```

If the story includes a migration:
```bash
<migration_apply_command>
<migration_roundtrip_command>   # round-trip required after every new migration
```

**Operator-path verification — MANDATORY for any story that adds or modifies an operator surface.**

If the story added or changed any of the following, you MUST run the actual command end-to-end from the documented operator environment before marking the story complete. Unit/lint/typecheck passing are necessary but **not sufficient** — they cannot detect bugs in container plumbing, env-var propagation, image cache freshness, mounted-secret handling, migration post-write hooks, or any other integration-boundary issue.

| Surface added/changed | Verification you must run |
|---|---|
| New build/run target | Run the target end-to-end; confirm exit 0 + observable side effect |
| New / modified install/bootstrap script | Run the script from a clean state; re-run to verify idempotency |
| Container/service / volume / healthcheck | Bring the stack up; confirm services healthy; targeted probe of the changed surface |
| Image build change (new layer, deps, ENV) | Rebuild the image; run a smoke command in the resulting container |
| Migration via your project's wrapper | Run the actual wrapper command; confirm the file landed at the expected host path with the expected revision id format |
| Endpoint exposed publicly | Hit the endpoint from the documented client environment and confirm response shape |

**Why this gate exists:** Integration-boundary bugs ship through CI green and surface in first-30-minutes operator testing — stale images missing deps, stub secrets without driver prefixes, build targets that assume env vars only present in CI, post-write hooks that crash inside the runtime image. Every one would have been caught by running the operator command once before declaring the story complete. CI's hermetic test layers cannot substitute for end-to-end operator-path execution.

If you cannot run the operator-path verification (e.g., no Docker daemon available in the agent environment), **escalate to the user** rather than skip — do not silently mark the story complete.

**Hard stop:** Do not proceed to frontend or commit if any check fails — including the operator-path verification.

### Step 4: Implement frontend changes (if story has frontend scope)

1. Read the UI Guidance section of the implementation plan.
2. Read the target component file(s) before editing.
3. Implement the changes described in the story, using the patterns from the UI Guidance section.
4. **Implement tooltips and contextual help** — if the plan's UI Guidance includes a tooltip inventory, implement every tooltip listed. Use the exact text and markup pattern from the plan. Do not skip tooltips — they are part of the feature, not decoration.
5. **Verify IA placement** — confirm the new UI element appears in the correct navigation position as specified in the plan's IA placement subsection.
6. **Grep-against-source for every option list / enum / dropdown** — before finalizing any component that renders a `<select>`, filter chip, status badge, sort control, or any array of `{value, label}` options whose wire value is sent back to the backend:
   - Identify the backend allowlist the values must match (cited in the plan's UI inventory or the spec's §8.4 "Enumerated value contracts").
   - `Grep` the cited backend file to enumerate the exact allowed values.
   - Compare character-for-character: every `value` in the frontend array must exist in the backend allowlist; every backend value the user should be able to select must appear in the frontend array.
   - Add a source-of-truth comment above the array pointing at `<backend_path>:<symbol>` so future edits don't drift.
   - If the plan omitted the backend source citation, STOP and update the plan before implementing — do not guess a plausible allowlist.
7. Verify the frontend typecheck passes: `<typecheck_command>` (or the frontend-specific equivalent).
8. If the plan specifies analogous markup, use it — do not invent new patterns.

### Step 5: Frontend verification gate (if frontend was touched)

```bash
<typecheck_command>             # TypeScript check or your project's typechecker
<frontend_build_command>        # Full build (catches SSR/import issues)
```

If E2E tests are scoped for this story:
```bash
<e2e_test_command> <test_file>
```

**Hard stop:** Do not commit if typecheck or build fails.

### Step 6: Write tests

Write tests required by the story's DoD and the plan's testing workstream:

- **Unit tests** — pure function tests, parametrized where appropriate.
- **Integration tests** — DB-backed, using your project's test fixtures.
- **Contract tests** — response shape assertions, auth gating, error code verification.
- **E2E tests** — real backend (no request mocking), **must use browser interactions**. API-level helpers are for test setup only; assertions must verify browser-visible behavior.

Follow existing test patterns in the codebase. Reference the canonical pattern files from `PROJECT_CONFIG.md`.

Run the tests:
```bash
<lint_command>                  # re-check after test files added
<unit_test_command> <test_file>  # targeted run
```

### Step 6b: Parallel test agents (optional optimization)

When a story requires tests across multiple layers (unit + integration + contract + E2E), the test layers can be written in parallel using worktree agents. Each test layer is independent — they test the same code but don't share files or state.

**When to use parallel agents:**
- Story requires 3+ test layers.
- Each layer has a clear test file path and pattern from the testing workstream.
- The code under test is committed and stable.

**When NOT to use parallel agents:**
- Story requires only 1-2 test files (overhead exceeds benefit).
- Tests have dependencies on each other.
- Frontend code is still in flux (E2E tests will break on UI changes).

**Pattern:** Launch up to 4 agents in parallel, each in an isolated worktree, with a prompt that includes the test path, the pattern file to follow, the behaviors to test, and the run command.

**After agents complete:**
1. Each agent returns its test file content and pass/fail result.
2. If any agent's tests fail, review the failure before merging.
3. Collect all test files from worktree agents into the main branch.
4. Run `<lint_command>` on the collected test files (agents may not match formatting).
5. Run the full targeted test suite to verify everything works together.

**Important:** Parallel agents are an optimization, not a requirement. If the story only needs a few tests, write them inline.

### Step 7: Commit

1. Stage only the files listed in the story's "New files" and "Modified files" tables, plus test files.
2. Verify nothing unexpected is staged: `git diff --cached --stat`.
3. Commit with a descriptive message referencing the story (use your project's `<commit_style>`):

```bash
git commit -m "$(cat <<'EOF'
<type>(<scope>): <summary> (Story X.Y)

<bullet points of key changes>
EOF
)"
```

### Step 8: Update progress

1. Mark the story as complete in the implementation plan's execution tracker (`[x]`).
2. Update TodoWrite task list.
3. Inform the user: story complete, what was done, what's next.

---

## Phase gate workflow

When all stories in a phase are complete, execute the phase gate:

### Step 1: Full test suite

```bash
<unit_test_command>
<integration_test_command>
<contract_test_command>
<lint_command>
<typecheck_command>
```

If frontend was touched in this phase:
```bash
<typecheck_command>             # frontend variant if separate
<e2e_test_command> <relevant_specs>
```

### Step 2: Cross-model code review

**This step is MANDATORY.** The cross-model review catches implementation drift from the plan.

**What to review:** The cumulative `git diff` for the phase (all story commits since the phase started).

**API call setup:**
1. Parse the API key: per `PROJECT_CONFIG.md` `<secondary_api_key_source>`.
2. Generate the diff: `git diff <phase_start_commit>..HEAD`.
3. Send to `<secondary_model>` with the implementation plan as context.

**Review prompt for the secondary model:**

```
You are reviewing code changes against an implementation plan. The diff shows
what was actually implemented. The plan shows what SHOULD have been implemented.

Check for:
1. Plan drift — code that diverges from the plan's key interfaces, endpoint
   tables, or data model
2. Missing implementations — plan items that don't appear in the diff
3. Unplanned changes — code changes not described in any story
4. Test coverage gaps — stories with DoD test requirements that have no
   corresponding test in the diff
5. Security concerns — auth bypass, missing tenant scoping, unsanitized input
6. Convention violations — direct third-party calls bypassing the configured
   abstractions, missing error handling, mutable state outside the domain layer

Return findings as JSON: {"findings": [{"severity": "High/Medium/Low",
"file": "path", "issue": "description", "suggestion": "fix"}]}
```

**Model:** Always use `<secondary_model>`. Pin `<secondary_api_token_param>` correctly.

**On cycle 2 and later — include the rejection log from earlier cycles** in the system prompt so the secondary doesn't re-raise findings already adjudicated. See spec-gen Step 6 for the exact rejection-log format. A repeats-only response in cycle N is a clean pass.

**Adjudication:** For each finding:
- **Accept** — fix the issue before proceeding.
- **Reject** — cite counter-evidence from the codebase. Log the rejection.
- **Escalate** — present to the user for decision.

**Major findings (High severity) block the phase gate.** Fix and re-review until clean.

### Step 3: Phase gate checklist

Verify every condition in the plan's phase gate section. Mark each as pass/fail.

---

## Post-implementation workflow

After all phases are complete:

### Step 0a: Worktree pre-flight — BLOCKING

Before anything else, audit the repo's worktrees. Stale locked worktrees chronically block `git checkout <default_branch>`, `git branch -d`, and finalization branch creation later in Step 8. Catch them up front, not at the point of failure.

Run:

```bash
git worktree list --porcelain | awk '/^worktree/ {print $2}'
```

For each worktree returned:

1. **Primary** (`<repo-root>`) — always keep. Never touched here.
2. **Named worktrees** (e.g., sibling checkouts) — check `stat -f %m <path>` (mtime). If older than 30 days, report to the user and ask: remove, fast-forward, or leave.
3. **Agent worktrees** (`.claude/worktrees/agent-*` or your harness's equivalent) — these come from agent calls that didn't clean up. For each locked one, verify the owning agent isn't running anymore, then offer to remove **only** after user approval.

**Never force-remove a worktree autonomously.** Report and wait for user direction.

**Deliverable:** a short table in the chat showing each worktree, its branch, age, and recommendation. User confirms → apply recommendations → proceed to Step 0b.

### Step 0b: Test coverage audit

**This step is MANDATORY before documentation or PR.** Compare the plan's testing workstream against actually written test files.

1. Read the plan's testing workstream (Section 3). List every test file it specifies across all layers (unit, integration, contract, E2E).
2. For each planned test file, check whether it exists on disk (`glob` the path).
3. Build a gap table:

| Planned test file | Exists? | Test count |
|---|---|---|
| `<path>` | Yes | 8 |
| `<path>` | **NO** | — |

4. If any planned test files are missing, write them before proceeding. Use parallel worktree agents (Step 6b pattern) for 3+ missing files.
5. Run the full test suite after writing missing tests to verify no regressions.

**Hard stop:** Do not proceed to documentation or PR if planned test files are missing.

#### Step 0b.1: Audit-event coverage audit (only if your project has audit-log infrastructure)

For every new `event_type` literal introduced by the diff (grep `git diff` for the audit-creation function call and string literals matching `[A-Z_]+` that are passed as the `event_type` argument):

1. **Event-type catalog:** confirm any new event type has been added to the canonical event-type catalog (a `Literal[...]` / enum / const block).
2. **Frontend display:** if the event surfaces in the UI, confirm a display-string mapping exists in the audit-event renderer component.
3. **Contract test:** confirm a contract test asserts the metadata shape on the audit row. Metadata canary check confirms no forbidden fields (credentials, tokens, PII beyond display-name strings) leak.
4. **Atomic emission:** confirm the audit_log INSERT happens inside the same transaction as the primary mutation, before commit.

**Hard stop:** Do not proceed to documentation or PR if any new tenant-visible event type is missing allowlist + IA + contract test coverage.

### Step 1: Extract deferred work

**This step is MANDATORY when the implementation plan covers only a subset of the spec's phases.**

1. Read the feature spec's "Phase boundaries" and "Scope" sections. Identify any phases that were NOT included in the implementation plan.
2. For each deferred phase, check whether a tracking file already exists.
3. If no tracking file exists for a deferred phase, create one at `<planned_features_root>/<feature_dir>/phase<N>_idea.md` with origin pointer, depends-on, proposed capabilities, scope signals, and why-deferred sections.
4. Commit the deferred work tracking file(s) with the documentation updates.

### Step 2: Documentation updates

Read the plan's documentation update workstream (Section 4). For each file:

- `<state_doc>` — update completion snapshot, migration head, active priorities.
- `<arch_doc>` — update if new services/layers/data flows were added.
- `<conventions_doc>` — update if new conventions/endpoints/error codes were added.

Commit documentation updates.

### Step 2.5: Tangential observations sweep — BLOCKING

Per your project's tangential-discoveries rule, every issue you noticed during this implementation that was NOT part of the current plan must be captured as an idea file before push — not held in conversation memory, not deferred to "later in the PR description."

This step is a safety net. The discipline is to capture inline as you notice; this sweep is the last chance to flush anything you missed.

Walk back through this implementation session and ask:

1. **Did I `git stash` to verify a failure was pre-existing on `<default_branch>`?** That's a tangential bug — it pre-existed and I confirmed it. If I didn't already file an idea, file one now.
2. **Did I see a test fail on first run, then pass on re-run, and "just re-run" without investigating?** That's a test-isolation bug. File an idea.
3. **Did I defer test coverage with "no framework available" / "manual smoke at staging" / "out of scope for a bug fix"?** That's an infra gap. File an idea.
4. **Did I read code that referenced a broken/stale path** (a TODO comment older than 6 months, a deprecated symbol still in use, an env var with no documentation)? Note it.
5. **Did I think "I should fix that someday" about anything**, even briefly? File the someday now.

For each, create `<planned_features_root>/<bug_|chore_|infra_>_<slug>/idea.md` per the idea template. Origin field MUST point at the PR or story that surfaced the observation.

**If you have nothing to file, state explicitly: "Tangential observations sweep: none found." in your end-of-step summary.** Silence is suspicious — the sweep is supposed to find things.

Commit the idea files (separate `docs(planned): capture <N> in-flight-noticed issues` commit on the same branch is acceptable).

### Step 3: Guide impact assessment — MANDATORY GATE

**This step is a hard gate, not a sub-task.** It runs between documentation and PR push and **blocks Step 8 (Finalize) if skipped**.

**This step is MANDATORY when the implementation touches tenant-facing UI.** If your project has no tenant-facing UI yet, write "Guide impact: N/A — no tenant-facing UI" and proceed.

Evaluate whether any existing walkthrough guides need to be regenerated or new guides need to be created:

1. **Read `docs/08_guides/README.md`** (or your project's guides index) to see the current walkthrough inventory.
2. **Read the route → guide mapping** in your guide-trigger component.
3. **For each modified frontend file in this implementation**, check:
   - Does the file appear in any guide's automation spec? If yes, that guide's screenshots are likely stale — flag for regeneration.
   - Did the implementation add, remove, or rename UI elements that appear in existing guide screenshots? If yes, flag those guides.
   - Did the implementation add a new page or feature that tenants need to learn? If yes, flag for new guide creation.
4. **Report findings to the user:**
   - **Regenerate:** "Guide NN may need regeneration — [file] was modified and appears in the guide's spec."
   - **New guide:** "This feature adds [page/flow] that isn't covered by any existing guide. Consider creating guide NN."
   - **Route mapping:** "This feature adds/changes the [page] — verify the route map still points to the correct guides."
5. **If the user approves**, run `/guide-gen NN --regen` for stale guides or `/guide-gen "flow description"` for new guides.
6. **Update the guide catalog** if a new guide was created.

### Step 4: Push and create PR

**Pre-push final gate.** Format + lint drift accumulates between the per-story Step 3 gate and now. Re-run the full gate in CI-parity mode **before pushing** so you don't waste a CI round-trip:

```bash
<format_command>                # auto-fix any drift
<lint_command>
<typecheck_command>
<format_check_command>          # exactly what CI runs
```

If `<format_command>` produced any diff, commit it first (`git add -A && git commit -m "style: apply format (pre-push)"`) before pushing.

```bash
git push -u origin <branch_name>
<pr_open_command> --title "<title>" --body "$(cat <<'EOF'
## Summary
<bullet points>

## Test coverage
<test counts by layer>

## Test plan
- [x] <unit_test_command>
- [x] <integration_test_command>
- [x] <contract_test_command>
- [x] <lint_command> && <typecheck_command>
- [ ] Staging verification after deploy
EOF
)"
```

### Step 5: Monitor CI

```bash
<ci_status_command>
```

If CI fails, investigate and fix before moving on.

### Step 6: Adjudicate automated reviewer comments

If your CI runs a bot reviewer (Gemini Code Assist, CodeRabbit, etc.), it typically posts within a few minutes of the PR opening. Treat this review with the same rigor as the cross-model protocol: classify every finding, adjudicate with cited counter-evidence, and post a single summary comment before merge.

#### Step 6.1: Fetch findings

Two surfaces to check:

```bash
# Summary review body (themes, counts, overall verdict)
<pr_view_command> <pr_number>

# Line-level inline comments (specific claims with path + line + severity icon)
<pr_comments_endpoint> > /tmp/bot_comments.json
```

Both are needed. The summary describes themes; the line comments are where the actual claims live. If no review has posted yet, wait and retry — do not skip this step.

#### Step 6.2: Classify each finding

For each line-level finding, assign exactly one verdict:

- **Accept** — the finding is correct. Fix it. Accepted fixes require a commit, push, and a re-triggered CI run before merge.
- **Reject** — the finding is wrong. Cite counter-evidence from the codebase (file:line) that disproves the claim. "I disagree" is not sufficient — show the code.
- **Defer** — the finding is valid but not a regression introduced by this PR (e.g., a pre-existing pattern, a UX improvement, an architectural suggestion for future work). Note it for a follow-up; do not fix in this PR.

**Common bot-reviewer failure modes worth naming explicitly:**

| Failure mode | How to spot it | Default adjudication |
|---|---|---|
| **Hunk-isolated false positive** | Bot claims a variable is undefined, a function call references a non-existent symbol, or imports are missing — but the surrounding (unchanged) code defines them. Bots review diff hunks without the rest of the file. | **Reject.** Cite the defining line. |
| **Spec-vs-code drift** | Bot claims the implementation disagrees with the spec. The spec may be wrong (pre-existing bug the frontend was living with). Verify against the actual backend route. | **Reject** the claim against the implementation. Note the spec needs correction. |
| **Correctness-shaped UX suggestion** | Bot uses High/Critical severity for what is actually a UX improvement (e.g., "add rollback on failure", "disable button during request"). Check whether the prior behavior was the same. | **Accept** if the PR introduced the regression. **Defer** if the pattern pre-exists. |
| **Severity inflation** | Bot marks defensive-code suggestions as "Critical" even when the branch is unreachable. | Verify reachability with a grep of the schema/migration. If unreachable, **reject** with the migration cite. |

#### Step 6.3: Apply accepted fixes

For each accepted finding:
1. Make the minimal change that addresses the root cause — not a defensive patch around it.
2. Re-run the frontend verification gate (`<typecheck_command>` plus any targeted E2E that covers the changed behavior).
3. Commit with a message that references the finding source.
4. Push. The PR CI will re-run automatically; wait for green before the summary comment.

Group small related fixes into one commit when they touch the same file — don't spam the PR with one commit per finding.

#### Step 6.4: Post adjudication summary on the PR

Post **one** comment on the PR that tables every finding with its verdict, so the human reviewer can see the full picture without re-reading each inline thread.

Template (fill in every row — rejected rows must include the counter-evidence cite):

````markdown
## Review adjudication

Commits landing fixes: `<sha1>`, `<sha2>`

### Automated reviewer (<N> findings)

| # | Sev | Location | Verdict | Notes |
|---|---|---|---|---|
| 1 | Critical | <path>:<LN> | **Rejected** | Counter-evidence: `<file>:<line>` defines `<symbol>`. Bot reviewed hunk without surrounding function context. |
| 2 | High | <path>:<LN> | **Accepted** | Fixed in `<short-sha>` — <one-line description>. |
| 3 | Medium | <path>:<LN> | **Deferred** | UX improvement; matches prior component's behavior; not a regression. Follow-up tracked as <note>. |

### Cross-model final review (<N> findings)

| # | Sev | Location | Verdict | Notes |
|---|---|---|---|---|
| … | … | … | … | … |

### Outcomes

- **Applied fixes (<N>):** <one-line list>
- **Rejected with cited counter-evidence (<N>):** <one-line list>
- **Deferred as non-regression follow-ups (<N>):** <one-line list>

Ready for human review + merge.
````

#### Step 6.5: Stop conditions

Proceed to Step 7 only when all of the following hold:
- Every line comment has a verdict entered in the adjudication table.
- Every Accept has a commit + green CI run.
- Every Reject has a file:line counter-evidence cite in the notes column.
- The summary comment has been posted on the PR.

If a finding is ambiguous (product decision, scope question), escalate to the user rather than forcing a verdict.

### Step 7: Final cross-model review

Run one final cross-model review of the complete PR diff:

```bash
git diff <default_branch>..HEAD
```

Send to `<secondary_model>` with the full implementation plan. This catches cross-story issues that per-phase reviews might miss.

**Include the phase-gate + bot-reviewer rejection log in the system prompt** so the final review doesn't re-raise findings already adjudicated. Use the same "Previously rejected findings — do NOT re-raise without new information" block. Merge both rejection logs (phase-gate + bot) into one list. A repeats-only final-review response is a clean pass.

### Step 8: Finalize — verify completion, update docs, move to implemented

> **Ad-hoc mode:** sub-steps 1, 3 (`pipeline_status.md`), 4 (`implementation_plan.md`), 6 (phase idea files), 7 (folder move) are SKIPPED. Sub-steps 0 (post-merge branch setup — derive the finalization branch slug from the **feature branch name** instead of a feature directory), 1a / 2 (guide impact), 5 (`<state_doc>` if applicable), 8 (commit + push), 9 (report completion) still apply.

**This step is MANDATORY after CI passes and review comments are addressed.** It closes out the feature lifecycle and ensures the feature is properly archived.

**0. Post-merge branch setup — BLOCKING if PR is merged.**

   Check the PR state:

   ```bash
   <pr_view_command> <pr_number> --json state,mergedAt
   ```

   - **If `state == "OPEN"`** — stay on the feature branch. Proceed to 8.1.
   - **If `state == "MERGED"`** — the feature branch is dead (squash-merged). Do NOT commit finalization edits on it; they'd go nowhere useful. Instead:

     ```bash
     git fetch origin <default_branch>
     git checkout -b docs/finalize-<feature-slug> origin/<default_branch>
     ```

     Never attempt `git checkout <default_branch>` directly — a sibling worktree may own it and block the checkout. Creating a new branch from `origin/<default_branch>` sidesteps the conflict cleanly.

   Slug convention: lowercase, kebab-case, derived from the feature directory name.

   After this step, all subsequent finalization commits land on the new branch and are merged via a second, docs-only PR.

1. **Verify implementation completeness:**
   - Read the implementation plan's execution tracker. Confirm every story is marked `[x]`.
   - For each story, spot-check that its key artifacts exist: new files created, modified files changed, test files present.
   - If any story is incomplete, stop and report the gap.

1a. **Pre-check: guide impact assessment must have run — BLOCKING.**
   Before proceeding to any of the steps below, verify that Step 3 (Guide impact assessment) was executed earlier in this workflow. Check for evidence:
   - A commit containing `docs(guides):` referencing a new or regenerated guide, OR
   - An explicit user-acknowledged "no guide impact" note in the PR body or in a commit message.

   If neither is present AND the implementation touched frontend code, **STOP finalization** and run the guide gate before continuing.

2. **Guide impact assessment (if frontend was touched):** Same evaluation as Step 3 (post-implementation) but placed here as a hard gate to ensure it is never skipped.

3. **Update pipeline_status.md:**
   - Change `## Implementation` status from `PR created` to `Complete`.
   - Add: date, PR number, CI status, stories completed count, review status.

4. **Update implementation_plan.md:**
   - Change the `**Status:**` field in the header to `Complete (PR #<number>, merged <date>)`.

5. **Update `<state_doc>`:**
   - Add the feature to `## Most recent meaningful changes` with a summary paragraph (component changes, test counts, key decisions).
   - Update `**Current focus:**` line.
   - Update `## Current branch / execution context`.

6. **Check for unimplemented phase idea files:**
   ```bash
   ls <planned_features_root>/<feature_dir>/phase*_idea.md 2>/dev/null
   ```
   - If any exist, **STOP** — do not move the folder.
   - Report the found files to the user and ask for instructions. The user may: (a) split phase idea files out to a new planned feature folder before moving, (b) implement the remaining phases first, or (c) explicitly confirm the move anyway.
   - Only proceed with the move after the user gives explicit instructions.

7. **Move feature folder to implemented_features:**
   ```bash
   mv <planned_features_root>/<feature_dir> \
      <implemented_features_root>/<YYYY_MM_DD>_<short_name>/
   ```
   - Date prefix uses the completion date (today).
   - Short name is a snake_case slug derived from the feature directory name.
   - The entire folder moves — spec, plan, pipeline_status, phase idea files all travel together.

8. **Commit and push** the finalization changes:
   ```bash
   git add <all changed files> && git commit -m "docs: move <feature> to implemented, update <state_doc>"
   git push
   ```

9. **Report completion** to the user with the final PR URL and a summary of what was archived.

**Why this step exists:** Without explicit finalization, completed features linger in `<planned_features_root>` and `pipeline_status.md` stays at "PR created" indefinitely. This creates stale state that confuses future planning sessions.

---

### Step 9: Post-merge local cleanup — BLOCKING

Run after both the feature PR and the finalization PR have merged. Closes out the local git state so future sessions don't resume on a dead branch and so stale agent worktrees don't accumulate.

**9.1 Fast-forward primary checkout.**

If a sibling worktree may own `<default_branch>`, never attempt `git checkout <default_branch>` in the primary checkout when it's on a feature branch. Instead:

```bash
git fetch origin <default_branch>
```

If the sibling worktree is stale and blocks you, fast-forward it in-place without touching the primary:

```bash
git -C <sibling_worktree_path> pull --ff-only origin <default_branch>
```

Never `git worktree remove --force` or `git worktree unlock` a sibling without **explicit user approval** — locked worktrees may hold in-flight work.

**9.2 Delete merged local branches.**

```bash
# Feature branch (squash-merged — use -D because squash doesn't preserve ancestry).
git branch -D <feature_branch_name>

# Finalization branch (same reason if squash-merged, else -d).
git branch -d docs/finalize-<feature-slug> 2>/dev/null || git branch -D docs/finalize-<feature-slug>
```

If a branch is "already checked out in worktree at <path>" — one of the agent worktrees still holds it. Proceed to 9.3.

**9.3 Agent worktree sweep.**

For each agent worktree still present:
- Verify the agent isn't running anymore.
- If done and no uncommitted work is visible, offer to remove with explicit user approval.

**9.4 Background process sweep.**

List any background processes this session started that are still running (CI watchers, dev servers, etc.) and decide per-process whether to keep them alive or terminate them.

**9.5 Report.**

End-of-session summary:
- Feature branch: deleted (or still held).
- Finalization branch: deleted.
- Agent worktrees removed: N.
- Agent worktrees remaining: N.
- Background processes remaining: N.

**Why this step exists:** without it, each completed feature leaves behind a dead local branch + 1–3 locked agent worktrees. After 5–10 features that becomes a full-day cleanup chore.

---

## Error handling

### Lint/typecheck failure
1. Read the error message.
2. Fix the specific issue (do not run `--fix` blindly for lint — review what it changes).
3. Re-run the check.
4. If the fix requires changing code you didn't write, verify it doesn't break existing behavior.

### Test failure
1. Read the test failure output.
2. Determine: is the test wrong, or is the code wrong?
3. If the test is wrong (testing the old behavior that was intentionally changed): update the test.
4. If the code is wrong: fix the code and re-run.
5. Never delete a failing test without understanding why it fails.

### Migration failure
1. If `<migration_apply_command>` fails: check the migration for syntax errors.
2. If `<migration_rollback_command>` fails: the downgrade implementation is wrong — fix it.
3. If round-trip fails: the upgrade creates state that downgrade doesn't fully reverse — fix the downgrade.
4. Always verify with a fresh `<migration_apply_command>` after fixing.

### Frontend build failure
1. `<typecheck_command>` errors: fix type issues.
2. `<frontend_build_command>` errors: may be SSR-related or import issues.
3. Read the full error — build tools often point to the wrong line.

---

## Manual steps

Some stories involve manual configuration outside the codebase (third-party app registration, deployment env vars, DNS changes, registering an external service, configuring an LLM provider, etc.). For these:

1. Read the relevant docs and any vendor links cited there.
2. Present step-by-step instructions to the user.
3. Wait for the user to confirm completion.
4. Verify the configuration (e.g., hit a health endpoint, round-trip a smoke request).
5. Update the implementation plan tracker.

---

## Rules

1. **Never commit to `<default_branch>`.** Always use a feature branch.
2. **Never skip a verification gate.** If lint fails, fix it. If tests fail, fix them. No `--no-verify`.
3. **Never implement beyond the story scope. Capture, don't carry.** If you see a bug or improvement opportunity orthogonal to the current story, do NOT fix it in this story's commit AND do NOT just "note it for later" in conversation memory. **Create an idea file immediately** at `<planned_features_root>/<bug_|chore_|infra_>_<slug>/idea.md` per the tangential-discoveries protocol. Idea files surface in `/pipeline --status` and persist across sessions; chat-noticings evaporate. The tangential-observations sweep flushes any uncaptured noticings before push as a safety net, but the discipline is to capture inline as you notice.
4. **Always read before editing.** Never modify a file you haven't read in this session.
5. **Always use `<secondary_model>` for cross-model review.** Never substitute a same-family model.
6. **Always update the plan tracker** after completing a story.
7. **Always run the full test suite** at phase gates — not just the tests you wrote.
8. **Frontend changes require the UI Guidance section.** If the plan doesn't have one, stop and ask the user to update the plan before implementing.
9. **Commit frequently** — one commit per story, not one giant commit per phase.
10. **Inform the user** at each story boundary: what was completed, what's next, any issues found.
