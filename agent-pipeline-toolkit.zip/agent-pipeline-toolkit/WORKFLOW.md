# Lifecycle & Documentation IA

The toolkit's workflow is opinionated. This document is the contract — read it once, then refer back when something doesn't fit. Skills enforce the rules here at runtime; understanding the rules saves you arguments with the agent.

## 1. The documentation IA

Documentation lives under `docs/` with a **numbered top-level taxonomy** so files sort predictably and related material stays grouped. Pick the narrowest section that matches the doc's primary audience and purpose.

```
docs/
├── 00_overview/                 ← project-level context, status, the umbrella spec, archives
│   └── implemented_features/    ← <YYYY_MM_DD>_<slug>/ folders move here when a feature ships
├── 01_architecture/             ← system design, technical overviews, interfaces, topology
├── 02_product/                  ← user stories, PRDs, planned-feature folders
│   └── planned_features/        ← <prefix>_<slug>/ folders for in-flight work
│       └── feature_templates/   ← templates copied into each new feature folder
├── 03_runbooks/                 ← operator and maintainer procedures
├── 04_security/                 ← threat models, policies, security guidance
├── 05_quality/                  ← testing strategy, quality gates, validation docs
├── 06_vendor_docs/              ← vendor- or engine-specific notes
├── 07_research/                 ← exploratory notes, comparisons, background analysis
├── 08_guides/                   ← tenant-facing walkthrough guides (lands later with UI)
└── 09_decisions/                ← ADR-style decision records (ADR-NNNN-title.md)
```

**Conventions:**

- **Numbers, not names, drive the IA.** `00_` sorts first, `09_` sorts last, the rest fall in between. Don't add a top-level section without a number.
- **Every section README is a directory.** A section README lists what's in the section + flags what's expected to arrive later. Short index files are good; sprawling tutorials in the README are bad.
- **Architecture is canonical; vendor specifics are not.** Keep vendor-specific behavior out of `01_architecture/` when a `06_vendor_docs/` note is more precise.
- **Durable decisions go to `09_decisions/`.** Anything you'd want to point a new hire at 18 months later — design tradeoffs, "why did we pick X over Y" — is an ADR. File-name pattern: `ADR-0001-pick-postgres-over-mysql.md`.
- **Feature specs cite arch docs, never duplicate them.** If a spec needs to explain how the auth model works, it cites `docs/01_architecture/auth.md` rather than repeating the explanation. When the arch doc changes, the spec stays correct.

## 2. The feature lifecycle

A feature starts as an `idea.md` and ends as a folder under `implemented_features/<YYYY_MM_DD>_<slug>/`. Between those two states it lives in `planned_features/<prefix>_<slug>/`.

### 2.1 Folder-prefix taxonomy

Every folder under `planned_features/` uses a **work-type prefix**:

| Prefix | Use for | Example |
|---|---|---|
| `feat_` | New user-facing capability or behavior | `feat_study_lifecycle/` |
| `bug_` | Defect fix with user-visible impact | `bug_trial_metric_off_by_one/` |
| `chore_` | Refactor, rename, dead-code removal, tech debt — no user-visible behavior change | `chore_rename_cluster_to_target/` |
| `infra_` | Deployment, CI, hosting, environment, dependency upgrades | `infra_bootstrap/` |
| `epic_` | Multi-phase bundle containing ≥2 dependent child feature folders | `epic_observability/phase_01_langfuse/` |

Rules:
- **One prefix per folder.** If work spans types (refactor that enables a new feature), pick the one the **user** sees first — usually `feat_`.
- **Domain is conveyed by the name, not by a second prefix.** `feat_study_lifecycle/` is obviously about study management; `feat_studies_management_lifecycle_v1/` is noise.
- **Epic children use `phase_NN_` numbering** for dependency order — `phase_01_xxx/`, `phase_02_yyy/`.
- **Keep the prefix short (≤6 chars)** so the descriptive tail gets the character budget.
- **Folder names should telegraph why the feature exists, not just what file it touches.**
  - `feat_report_freshness` → too vague; `feat_report_30day_refresh` says what ships.
  - `epic_auto_apply_changes` → too aspirational; `feat_changes_pr_open_and_merge` says what the first version actually does.

### 2.2 The five stages

```
IDEA ──▶ SPEC ──▶ PLAN ──▶ IMPLEMENT ──▶ DONE
  1        2        3          4           5
```

Each stage has an input artifact, a skill that drives it, an output artifact, and an approval gate before the next stage starts.

| Stage | Input | Skill | Output | Gate |
|---|---|---|---|---|
| **IDEA** | (nothing) | (manual) | `idea.md` | Author writes idea using `idea-template.md` |
| **SPEC** | `idea.md` | `/spec-gen` | `feature_spec.md` | User approves spec (gating handled in skill) |
| **PLAN** | `feature_spec.md` | `/impl-plan-gen` | `implementation_plan.md` | User approves plan |
| **IMPLEMENT** | `implementation_plan.md` | `/impl-execute --all` | code + PR + CI green | Per-story gates + final cross-model review |
| **DONE** | PR merged | (automatic) | folder moves to `implemented_features/` | Staging deploy verified (if applicable) |

**`pipeline_status.md`** lives inside each feature folder and tracks which stages are complete. The `/pipeline` orchestrator reads it on every invocation to decide what's next.

### 2.3 The orchestrator: `/pipeline`

`/pipeline` is the entry point you'll use 90% of the time. It does **stage detection** and invokes the right specialist skill.

```
/pipeline status
    → renders a project-wide status table, sorted by dependency-derived priority,
      with one explicit "Next action: advance feature X from stage Y to Z" line

/pipeline docs/02_product/planned_features/feat_foo
    → detects what stage feat_foo is at, invokes the right next skill, pauses at the
      approval gate

/pipeline docs/02_product/planned_features/feat_foo --auto
    → autonomous mode: runs idea → spec → plan → implement → PR without inter-stage pauses
      (quality gates within each skill still fire; just the "do you approve the spec?"
      pauses are skipped)

/pipeline docs/02_product/planned_features/feat_foo --from spec
    → force start from a specific stage regardless of detected state

/pipeline docs/02_product/planned_features/feat_foo --to plan
    → stop after completing a specific stage (useful for "generate just the plan, don't
      start implementing")
```

In **epic mode** (a parent folder with `phase_NN_*/` children), `/pipeline` processes phases sequentially — each phase goes through the full pipeline before the next starts, and `--auto` mode still pauses between phases so dependent work doesn't start on stale code.

### 2.4 Idea preflight

`idea.md` files get stale. By the time you actually run `/pipeline` on a feature you scoped 6 weeks ago, the file paths in it may be wrong, the function it references may have been renamed, and the deferral rationale ("waiting for X to ship first") may be obsolete because X shipped two weeks ago.

`/idea-preflight` audits an `idea.md` against the current code and applies patches in-place (mode: Audit & Patch by default). It:

- Verifies every concrete claim (paths, function names, counts, line numbers).
- Audits "preserved capability" claims by reading the actual current source — the highest-leverage check.
- Forces decisions on open `Option A vs Option B` forks (locks ones it can; surfaces ones requiring user judgment).
- Checks the folder name against the prefix + intent-clarity convention.
- Cross-checks against siblings (does this feature coordinate with adjacent in-flight work?) and against recently-shipped features (does anything just ship that retires this idea's deferral rationale?).

The skill never commits — it lands patches in the working tree, and you review the diff before shipping.

Run preflight when:
- The `idea.md` is more than 2 weeks old AND you're about to run `/pipeline` on it.
- You're not sure whether the idea still describes work that needs to happen.
- The idea contains terms like "approximately" or "~" against numbers (those drift fastest).

### 2.5 Per-stage artifacts and gates

#### SPEC (`/spec-gen`)

Reads: `idea.md` + project context (`CLAUDE.md`, `architecture.md`, `state.md`) + the feature-spec template.

Writes: `feature_spec.md` covering purpose, scope, current-state audit, API surface, data model, security, UX flows, acceptance criteria, test strategy, rollout, traceability matrix, decision log, open questions.

Gates:
- **Codebase accuracy pass** — every file path, function name, column, endpoint, error code verified by reading the actual code.
- **Architectural consistency pass** — does the spec respect your absolute rules? Are invariants written-path-audited?
- **Cross-model review** — secondary model audits with a rejection-log + max-3-cycle convergence loop.
- **Findings gate** — major findings (contract changes, data-model changes, security implications) require user approval before being applied.
- **Deferred-phase tracking** — if the spec defines multiple phases, every phase beyond Phase 1 gets a `phase<N>_idea.md` tracking file in the same folder.

Modes:
- **Generate** — new spec from an idea
- **Review** — audit an existing spec (returns findings only)
- **Reconcile** — diff an input brief against a spec
- **Review & Patch** — apply findings to an existing spec

#### PLAN (`/impl-plan-gen`)

Reads: `feature_spec.md` + project context + the implementation-plan template.

Writes: `implementation_plan.md` covering FR → story traceability, epic/phase structure, per-story scope (new files, modified files, endpoints, key interfaces, schemas, tasks, DoD), UI guidance (if frontend), testing workstream, documentation update workstream, refactor scope, sequencing, execution tracker, story verification gate.

Gates:
- **Plan-internal consistency pass** — every spec FR has a story; every spec endpoint appears in exactly one story; every spec error code appears in a contract test task; every test file in the testing workstream is assigned to a story.
- **Codebase accuracy pass** — file paths exist, state-variable names match, frontend data plumbing is real (not invented).
- **Cross-model review** — secondary model audits with the same rejection-log + convergence-loop pattern.
- **Findings gate** — major findings require approval.

#### IMPLEMENT (`/impl-execute`)

Reads: `implementation_plan.md` + project context.

Writes: code, tests, docs updates, commits, the PR.

Per-story gates:
1. **Read scope & verify file paths** (modified files still exist where the plan claims).
2. **Implement backend changes** (models → migration → repo → domain → service → router → schemas).
3. **Backend verification gate** — `<lint>`, `<typecheck>`, `<format_check>`, targeted test suites. Migration round-trip if schema changed. **Operator-path verification** if the story added a new operator surface.
4. **Implement frontend changes** following the plan's UI Guidance section.
5. **Frontend verification gate** — `<typecheck>`, `<build>`, E2E if scoped.
6. **Write tests** matching the story's DoD.
7. **Commit** — one commit per story, descriptive message referencing the story ID.
8. **Update progress tracking** in the plan's execution tracker.

Phase gates (when all stories in a phase are done):
- Full test suite passes.
- **Cross-model code review** on the cumulative diff. Same rejection-log + convergence pattern as spec/plan.
- Phase gate checklist from the plan passes.

Post-implementation (after the last story):
- **Worktree pre-flight** — detect stale or locked sibling worktrees that would block finalization later.
- **Test coverage audit** — every test file the plan promised exists. Missing tests get written before PR.
- **Extract deferred work** — every spec phase not covered by this plan gets a `phase<N>_idea.md` tracking file.
- **Documentation updates** — `state.md`, `architecture.md`, `CLAUDE.md` (or your project's equivalents) reflect what shipped.
- **Tangential-observations sweep** (BLOCKING) — every issue you noticed during implementation that wasn't part of the plan gets filed as an idea file. Silence is suspicious — the sweep is supposed to find things.
- **Guide impact assessment** (MANDATORY GATE if UI was touched) — does any existing walkthrough guide need regeneration? Does the feature need a new guide?
- **Push & open PR** with a structured body (Summary / Test coverage / Test plan).
- **CI watch** — monitor the workflow until green.
- **Automated review adjudication** — if your CI runs a bot reviewer (Gemini Code Assist, CodeRabbit, etc.), every finding gets a verdict (accept / reject / defer) with cited counter-evidence. The skill posts a summary comment on the PR.
- **Final cross-model review** on the complete diff.
- **Finalize** — verify completion, update tracking files, move the folder to `implemented_features/`.
- **Post-merge cleanup** — delete merged branches, sweep stale agent worktrees.

#### Ad-hoc mode

For small bug fixes / refactors / Gemini-feedback follow-ups that don't warrant `/pipeline` scaffolding:

```
/impl-execute --ad-hoc
```

Skips the per-story workflow (there's no plan), keeps the post-implementation ceremony (pre-push gate, push, PR, CI watch, bot-reviewer adjudication, post-merge cleanup). Use when:
- The change is ≤5 files, ≤100 LOC of non-test code.
- The change has no design surface (no open forks, no migration, no cross-layer ownership decisions).
- The user already did the actual code work and just needs the ship ceremony.

Don't use ad-hoc when the change introduces a new feature surface, requires a migration, or affects an absolute-rule surface. Run `/pipeline` instead.

### 2.6 The bug-fix protocol

`/bug-fix` is the missing middle between direct ad-hoc execution (too informal for bugs with design surface) and `/pipeline` (over-scaffolded for ~200-LOC fixes).

Use when the bug has:
- A design fork to lock (e.g., "should we drop legacy events or migrate them?")
- New migration OR new prompt OR cross-layer ownership
- Roughly 50–500 LOC
- Worth a single-file `bug_fix.md` design doc but not a full spec + plan

The skill walks 6 phases:

1. **Triage** — is this the right tool? (Trivial → direct edit. Feature-scale → /pipeline. Stale idea → preflight first.)
2. **Reproduce first** — write or run the failing test before changing any code. The reproducer becomes the regression test.
3. **Root-cause trace** — name the layer that owns the bug. Cite file:line. Distinguish root cause from symptoms.
4. **Lock the design forks** — for each open Option A vs Option B, lock-with-rationale (engineering judgment) or escalate (product/UX judgment).
5. **Write `bug_fix.md` and implement** — ~80-line artifact + the actual code change + the regression test. Tangential discoveries get captured as idea files in the same branch.
6. **Handoff** to `/impl-execute --ad-hoc` for the ship ceremony.

The artifact is short by design (~80 lines, hard cap ~150): Problem / Reproduction / Root cause / Fix design / Regression test plan / Rollout / Tangential observations.

## 3. The "planned → implemented" handoff

The most common confusion: when does a feature's folder physically move from `planned_features/` to `implemented_features/`?

### 3.1 The default move conditions

A folder moves when **all** of these hold:

1. The PR for the feature is **merged** to the default branch.
2. CI passed on the merge commit.
3. The implementation plan's execution tracker has every story marked `[x]`.
4. The `pipeline_status.md` `## Implementation` section is updated to `Complete (PR #N, merged YYYY-MM-DD)`.
5. The implementation plan's header `**Status:**` field is updated to `Complete (PR #N)`.
6. `state.md` reflects the new state (feature added to "Most recent meaningful changes", branch context updated).
7. **No unresolved `phase*_idea.md` files** — if the feature had deferred phases, each phase's tracking file has been consciously handled (split out to a new planned feature folder OR explicitly confirmed for deferral with the user).
8. Guide impact assessment ran and either regenerated stale guides, created new ones, or recorded a "no impact" rationale.

When all 8 conditions hold, the move is:

```bash
mv docs/02_product/planned_features/<feature_dir>/ \
   docs/00_overview/implemented_features/<YYYY_MM_DD>_<short_name>/
```

The entire folder moves — `idea.md`, `feature_spec.md`, `implementation_plan.md`, `pipeline_status.md`, any `phase*_idea.md` that won't be split out, the `bug_fix.md` (if it was a /bug-fix flow). Everything travels together so the archive is self-contained.

The `YYYY_MM_DD` prefix is the completion date (the day the move happens). The `short_name` is a snake_case slug derived from the original folder name with the prefix stripped or preserved as you prefer — pick one convention and stick with it.

### 3.2 Why the move matters

Without an explicit move, finished features linger in `planned_features/` and the project-wide status (`/pipeline status`) keeps showing them as "in flight." That creates two problems:

- **Stale state.** Next quarter someone looks at the planned-features list and sees 40 folders, half of which actually shipped six months ago. The list stops being useful.
- **Invisible deferred work.** If you finish Phase 1 of a 3-phase feature and move the folder without addressing the `phase2_idea.md` and `phase3_idea.md` files, the deferred phases vanish.

The move is the canonical "this is done" signal. Skills enforce it; manual finalization is the same checklist.

### 3.3 The post-merge cleanup

The move is on a **separate, docs-only PR**. Reason: the feature's PR (the one with the actual code) has already been squash-merged, and its branch is dead — committing finalization edits to a dead branch sends them nowhere. The flow is:

1. Feature PR merged.
2. Locally: `git checkout -b docs/finalize-<feature-slug> origin/main`.
3. Land all finalization edits on this new branch (`pipeline_status.md` update, plan status flip, `state.md` update, folder move).
4. Push, open a docs-only PR with title `docs: move <feature> to implemented`, body `Closes #<feature_pr_number>`.
5. Merge once CI is green.
6. Delete both the original feature branch (`git branch -D`) and the finalization branch.

Skills automate this in `/impl-execute` Step 8 (Finalize) — the user only needs to merge the docs PR.

## 4. Cross-model review — the rejection log

Every artifact the skills generate gets reviewed by a secondary model. The pattern is:

1. Primary writes the artifact.
2. Secondary reviews with focus areas the primary is weak at (e.g., for a spec: contract accuracy, data-model accuracy, downstream consumer coverage).
3. Secondary returns findings as JSON: `{claim, evidence, severity, location}`.
4. Primary adjudicates:
   - **Accept** — cite the evidence, log the correction.
   - **Reject** — cite **counter-evidence from the code** (file:line). "I disagree" is not allowed.
   - **Escalate** — present to the user.
5. If accepted corrections changed a *major* element, re-send for another cycle.

### The rejection log

On cycle 2+, the prompt to the secondary includes a **rejection log** from earlier cycles:

```
## Previously rejected findings (do NOT re-raise without new information)

The following findings were raised in prior cycles and rejected with cited counter-evidence:

- Cycle 1 finding #N: "{short quote of the claim}"
  Rejection: {one-line counter-evidence with file:line}
...

You may re-raise a listed finding ONLY if you have new information (code change since
last cycle, corrected citation, genuinely different angle). "Disagreeing with the
rejection" is not new information.
```

This prevents convergence loops where the secondary re-raises the same findings every cycle.

### The convergence stop rules

The loop stops when:
- The secondary reports no new High-severity findings AND the primary has no unresolved accepted changes.
- The secondary returns only findings the primary already rejected with cited counter-evidence in a previous cycle (no new info).
- 3 cycles have run.

If convergence isn't reached at cycle 3, the remaining disagreements get presented to the user for resolution. The agent doesn't loop forever and it doesn't silently pick a side.

## 5. "Capture, don't carry" — tangential discoveries

The single most important discipline this toolkit enforces: **when the agent notices an unrelated bug or improvement during a task, it files an idea file immediately, not "for later."**

The opposite — holding the noticing in conversation memory and mentioning it in the PR description — looks reasonable but reliably fails:

- Conversation memory evaporates between sessions.
- PR descriptions don't surface in `/pipeline status`.
- A list of "things I noticed" in a chat reply is dead text.

An idea file (`docs/02_product/planned_features/<prefix>_<slug>/idea.md`) is the only durable carrier. It surfaces in status reports, in `ls` output, in grep. Future agents and future humans see it.

The skills implement this in two places:

- **Inline during a task** — the moment the agent notices something, it files the idea file and continues. No "I'll come back to this" — the artifact IS the coming back.
- **Tangential-observations sweep** (BLOCKING gate in `/impl-execute` post-implementation) — last chance to flush anything missed inline. The agent walks back through the session and asks: did I `git stash` to verify something? Did a test flake on first run? Did I defer test coverage with "no framework available"? Each is an idea file.

The sweep's explicit termination is: **"Tangential observations sweep: none found"** — silence is suspicious; the sweep is supposed to find things.

## 6. Skills map to lifecycle

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                                                                                  │
│   IDEA STAGE                                                                     │
│   ─────────                                                                      │
│                                                                                  │
│   idea-template.md  ─────▶  authored manually  ─────▶  idea.md                   │
│                                                          │                       │
│                                                          ▼                       │
│                                              /idea-preflight (audit & patch)     │
│                                                          │                       │
│                                                          ▼                       │
│                                                  ready idea.md                   │
│                                                                                  │
│   SPEC STAGE                                                                     │
│   ──────────                                                                     │
│                                                                                  │
│   feature-spec-template.md + idea.md                                             │
│                          │                                                       │
│                          ▼                                                       │
│              /spec-gen ───────▶ feature_spec.md                                  │
│              (cross-model review,                                                │
│               findings gate,                                                     │
│               deferred-phase tracking)                                           │
│                                                                                  │
│   PLAN STAGE                                                                     │
│   ──────────                                                                     │
│                                                                                  │
│   implementation-plan-template.md + feature_spec.md                              │
│                          │                                                       │
│                          ▼                                                       │
│              /impl-plan-gen ─────▶ implementation_plan.md                        │
│              (cross-model review,                                                │
│               consistency audit)                                                 │
│                                                                                  │
│   IMPLEMENT STAGE                                                                │
│   ───────────────                                                                │
│                                                                                  │
│   implementation_plan.md                                                         │
│                          │                                                       │
│                          ▼                                                       │
│              /impl-execute (per-story gates, phase gates,                        │
│                             post-impl ceremony, finalize)                        │
│                          │                                                       │
│                          ▼                                                       │
│              code + PR + CI green + folder moved to implemented_features/        │
│                                                                                  │
│                                                                                  │
│   SIDE PATHS                                                                     │
│   ──────────                                                                     │
│                                                                                  │
│   Medium-sized bug?     /bug-fix ──▶ bug_fix.md + committed fix ──▶              │
│                            /impl-execute --ad-hoc                                │
│                                                                                  │
│   Tiny one-off fix?     direct edit ──▶ /impl-execute --ad-hoc                   │
│                                                                                  │
│   UI changed?           /guide-gen (invoked by /impl-execute post-impl)          │
│                                                                                  │
└──────────────────────────────────────────────────────────────────────────────────┘
```

## 7. When things go wrong

| Failure | What to do |
|---|---|
| Skill stops at a gate with "major finding requires approval" | Read the finding, accept or reject with code evidence, re-run the skill. The skill resumes from where it stopped. |
| Cross-model review convergence not reached at cycle 3 | The skill surfaces the remaining disagreements. You decide. The skill then proceeds with your decision. |
| Story verification gate fails (lint, test, etc.) | The skill stops and shows the failure. Fix the code; re-run the story. The skill picks up at the failed gate. |
| Skill claims a file doesn't exist that you know exists | Check the path the skill used. Your repo layout may not match `PROJECT_CONFIG.md`. Update the config, retry. |
| Two skills conflict on what stage a feature is at | The `pipeline_status.md` file is the source of truth. If it's out of sync with reality, edit it manually. |
| `phase*_idea.md` keeps showing up after Phase 1 ships | That's correct — it's deferred work tracking. Either split it out to a new planned feature folder (the agent can do this via `/pipeline`) or explicitly confirm deferral when finalizing. |
| Folder move fails because a sibling worktree owns `main` | The skill catches this in worktree pre-flight (Step 0a of post-implementation). Either fast-forward the sibling in place or wait until the worktree is freed. |

## 8. Authoring an idea.md from scratch

Most often a feature starts because someone (you, a teammate, a customer) said "we should be able to X." Translate that into an `idea.md` using these steps:

1. Pick the prefix. Almost always `feat_` for new user-facing work, `bug_` for defects, `chore_` for tech debt, `infra_` for ops/CI, `epic_` for multi-phase bundles.
2. Pick the slug. 4–6 snake-case tokens telegraphing **why** the feature exists — `feat_report_30day_refresh`, not `feat_report_freshness`. Single-token names are too vague; 8+ token names are too verbose.
3. Create the folder: `mkdir docs/02_product/planned_features/<prefix>_<slug>/`.
4. Copy the template: `cp docs/02_product/planned_features/feature_templates/idea-template.md docs/02_product/planned_features/<prefix>_<slug>/idea.md`.
5. Fill in the placeholders. Be concrete; vague ideas produce vague specs.
6. (Optional but recommended) Run `/idea-preflight` to audit the idea against the current code before invoking the pipeline.
7. Run `/pipeline docs/02_product/planned_features/<prefix>_<slug>` to advance to SPEC.

That's it. The skills handle everything from there.

## 9. What this workflow is NOT

- **It is not a project-management system.** There's no Jira-like ticket lifecycle, no estimation, no sprint planning. The folders are the work; `/pipeline status` is the dashboard.
- **It is not branching strategy guidance.** The skills assume short-lived feature branches off a stable default branch. If you use trunk-based development or Gitflow, adapt the branch-creation steps in `impl-execute`.
- **It is not a CI replacement.** The skills run verification gates locally before push so CI doesn't waste cycles, but CI is the final word. If your CI is missing important checks (e.g., no coverage gate), add them — don't rely on the skills.
- **It is not a substitute for code review.** Cross-model review catches a lot, but human review catches different things. The pipeline opens a PR; humans still review and merge.
