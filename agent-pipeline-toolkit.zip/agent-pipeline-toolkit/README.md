# Agent Pipeline Toolkit

A drop-in set of Claude Code skills and feature templates that drive a complete idea → spec → plan → implement → ship lifecycle, with cross-model review at every stage and a disciplined documentation IA.

This toolkit was extracted from a working production codebase where the pipeline shipped dozens of features. It has been generalized so any team can install it into their repo and run the same workflow against their own stack.

## What's in the box

```
agent-pipeline-toolkit/
├── README.md                                          ← you are here
├── INSTALL.md                                         ← drop-in instructions
├── WORKFLOW.md                                        ← full lifecycle + docs IA
├── PROJECT_CONFIG.md                                  ← stack placeholders the agent fills in
│
├── .claude/
│   └── skills/                                        ← 7 invocable skills
│       ├── pipeline/SKILL.md                          ← orchestrator (top-level entry point)
│       ├── idea-preflight/SKILL.md                    ← audit idea.md against current code
│       ├── spec-gen/SKILL.md                          ← idea → feature_spec.md (+ cross-model review)
│       ├── impl-plan-gen/SKILL.md                     ← spec → implementation_plan.md (+ cross-model review)
│       ├── impl-execute/SKILL.md                      ← plan → code + PR + CI green
│       ├── bug-fix/SKILL.md                           ← medium-bug protocol (repro → root cause → fix)
│       └── guide-gen/SKILL.md                         ← walkthrough guides with visual audit
│
└── docs/
    └── 02_product/
        └── planned_features/
            └── feature_templates/
                ├── README.md                          ← folder-prefix taxonomy
                ├── idea-template.md                   ← lightweight idea capture
                ├── feature-spec-template.md           ← full feature spec
                └── implementation-plan-template.md    ← story-by-story plan
```

## The lifecycle in one diagram

```
┌─────────┐    ┌──────────────┐    ┌──────────┐    ┌────────────┐    ┌────────────┐    ┌──────┐
│ idea.md │──▶ │ /idea-       │──▶ │ /spec-   │──▶ │ /impl-     │──▶ │ /impl-     │──▶ │ DONE │
│         │    │  preflight   │    │  gen     │    │  plan-gen  │    │  execute   │    │      │
└─────────┘    └──────────────┘    └──────────┘    └────────────┘    └────────────┘    └──────┘
   capture       audit & patch       feature_         implementation_     code + PR        merged
   what,         against current     spec.md          plan.md             + CI green       + folder
   why,          code; lock                                                                moves to
   how big      open forks                                                                 implemented_
                                                                                          features/

                              ┌────────── /pipeline (orchestrates) ──────────┐

For medium-sized bugs (~50–500 LOC, has design surface), use /bug-fix instead — it produces a
focused bug_fix.md and a committed fix, then hands off to /impl-execute --ad-hoc to ship.

For tiny one-line fixes, skip the pipeline entirely — just edit, commit, and run
/impl-execute --ad-hoc.
```

## What each skill does

| Skill | Stage | One-line summary |
|---|---|---|
| `/pipeline` | orchestrator | Detects which stage a feature is at, invokes the right skill, pauses for approval between stages. Also has a project-wide `status` mode. |
| `/idea-preflight` | pre-pipeline | Reads an `idea.md` and audits every concrete claim against the current code (paths, function names, counts), forces decisions on open forks, applies safe patches in-place. |
| `/spec-gen` | stage 1 | Generates a `feature_spec.md` from an `idea.md`. Verifies every claim, runs cross-model review with a rejection-log + max-3-cycle convergence loop, gates major findings for user approval. |
| `/impl-plan-gen` | stage 2 | Generates a story-by-story `implementation_plan.md` from an approved spec. Verifies spec ↔ plan ↔ codebase alignment. Same cross-model review pattern. |
| `/impl-execute` | stage 3 | Executes the plan story-by-story with verification gates (lint, typecheck, tests), runs phase-gate code review, opens a PR, adjudicates automated PR comments, runs final cross-model review, moves the folder to `implemented_features/`. |
| `/bug-fix` | stage 1b | Drives a medium-sized bug through reproduce-first → root-cause → lock design forks → write `bug_fix.md` + commit the fix. Hands off to `/impl-execute --ad-hoc`. |
| `/guide-gen` | stage 3.1 | Generates tenant-facing walkthrough guides with browser-captured screenshots and a cross-model visual audit. Conditional — invoked by `/impl-execute` when UI changes. |

## Why this toolkit exists

Most AI coding assistants happily generate code from a one-line prompt. That works for toy problems and fails predictably on real ones — wrong file paths, invented APIs, missed downstream consumers, drift between what the spec promised and what the code does.

The toolkit's premise is that quality comes from **verification at every boundary**, not from making the model smarter. Every artifact (idea, spec, plan, code) gets:

1. **Grounded against the codebase** — every file path, function name, column name, error code is verified by reading the actual repo before being written.
2. **Reviewed by a second model** — a different model family (Gemini, GPT-5, a local model — whatever you wire in) audits each artifact with focus areas the primary model is weak at. Findings get adjudicated with cited counter-evidence; "I disagree" is not allowed.
3. **Gated for user approval** — major findings (contract changes, data-model changes, security implications) require explicit user sign-off before moving forward.
4. **Captured in a structured artifact** — `idea.md`, `feature_spec.md`, `implementation_plan.md`, `bug_fix.md`, `pipeline_status.md`. The conversation is ephemeral; the artifacts persist and are the authoritative record.

## Quick start

1. Unzip into the **root of your repository** so `.claude/` and `docs/` merge with what's there.
2. Open `INSTALL.md` and follow the 5-step setup — it walks you through filling in `PROJECT_CONFIG.md` with your stack's lint/typecheck/test/format commands, your migration tool, and your cross-model reviewer of choice.
3. Read `WORKFLOW.md` to see how the docs IA, folder-prefix taxonomy, and idea → done lifecycle fit together.
4. Try it: create an `idea.md` in `docs/02_product/planned_features/feat_<your_feature>/` and run `/pipeline docs/02_product/planned_features/feat_<your_feature>`.

## Design philosophy

- **Skills don't duplicate logic.** The orchestrator invokes specialist skills; each specialist owns one stage.
- **Artifacts over conversations.** Every decision lands in a file you can grep, diff, and review.
- **Reproduce before fixing, verify before claiming.** No "trust me" assertions — every claim has a code citation.
- **Capture, don't carry.** When the agent notices an unrelated bug or improvement during a task, it files an idea file immediately rather than holding it in conversation memory.
- **Hard gates are non-negotiable.** Lint failure, test failure, missing operator-path verification, unresolved high-severity finding — all stop the pipeline. The agent cannot waive them.

## Compatibility

- **Claude Code / Claude desktop with Cowork mode** — primary target. Skills are invoked via the slash-command pattern (`/pipeline`, `/spec-gen`, etc.).
- **Other agent harnesses** — the SKILL.md files are plain markdown with a YAML frontmatter block; any harness that loads skills from a `.claude/skills/` convention will work.
- **No language lock-in** — the skills reference stack-specific commands through `PROJECT_CONFIG.md` placeholders, so they work for Python, TypeScript, Go, Rust, Java, etc.

## License & attribution

This toolkit was extracted from a working codebase and generalized for reuse. Use freely. If you ship improvements upstream, the contribution is appreciated but not required.
