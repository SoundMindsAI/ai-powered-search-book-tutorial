# Installation

This toolkit installs into an existing repository by **merging** its `.claude/` and `docs/` folders with whatever you already have. There is no build step and no runtime dependency — the skills are plain markdown files that agents read on demand.

## Step 1 — Unzip into your repo root

Unzip the toolkit at the **top level** of your repository (the folder that contains `.git/`):

```bash
cd /path/to/your/repo
unzip /path/to/agent-pipeline-toolkit.zip
```

Or, if you already cloned/extracted the toolkit elsewhere:

```bash
cp -r agent-pipeline-toolkit/.claude .
cp -r agent-pipeline-toolkit/docs .
cp agent-pipeline-toolkit/{README.md,INSTALL.md,WORKFLOW.md,PROJECT_CONFIG.md} ./docs/agent-pipeline-toolkit/
```

After this step you should see (or have merged into):

```
your-repo/
├── .claude/skills/{pipeline,idea-preflight,spec-gen,impl-plan-gen,impl-execute,bug-fix,guide-gen}/SKILL.md
├── docs/
│   └── 02_product/
│       └── planned_features/
│           └── feature_templates/{README,idea-template,feature-spec-template,implementation-plan-template}.md
├── PROJECT_CONFIG.md
├── README.md            ← from the toolkit; rename if you already have one
├── INSTALL.md
└── WORKFLOW.md
```

> **If you already have a `.claude/skills/` folder:** merge the toolkit's skills in alongside yours. The skill names (`pipeline`, `idea-preflight`, etc.) shouldn't collide with anything else unless you've built your own pipeline. If they do, rename the toolkit's skills (e.g., `tk-pipeline`) and update internal cross-references.
>
> **If you already have a `docs/` folder with a different numbering scheme:** keep yours and just drop `feature_templates/` into the path your team uses for planned features. Update the path references inside `WORKFLOW.md`, `PROJECT_CONFIG.md`, and each SKILL.md (they all reference `docs/02_product/planned_features/`).

## Step 2 — Fill in PROJECT_CONFIG.md

`PROJECT_CONFIG.md` is the single place where you tell the skills about your stack. The skills reference it via `<placeholder>` syntax, so once you fill it in, every skill speaks your language.

Open `PROJECT_CONFIG.md` and replace every `<...>` with a concrete value for your project. The main blocks:

- **Build/test commands** — what to run for lint, typecheck, format, unit tests, integration tests, contract tests, E2E tests
- **Migration tooling** — name of your migration tool, how to create/apply/round-trip migrations
- **Source-tree layout** — where backend code lives, where frontend code lives, where tests live
- **Cross-model reviewer** — which model you'll use as the second opinion (Gemini, GPT-5, a local model, an in-house reviewer service, etc.) and how to call it
- **PR / CI tooling** — `gh`, `glab`, custom — and how you watch CI runs
- **Coding conventions** — repo function signatures, async patterns, error envelope shape

You don't have to fill it all in on day one. The skills will work with partial configuration — just make sure the blocks for the stages you're about to run are populated.

## Step 3 — Create or update root context files

The skills always read three "root context" files at the start of every run. Create them if they don't exist:

| File | Purpose | If missing |
|---|---|---|
| `CLAUDE.md` (or `AGENTS.md`) | Project conventions, absolute rules, stack overview | Skills run with reduced context; consider creating one |
| `architecture.md` | System design, boundaries, critical flows | Skills will infer from code; less reliable |
| `state.md` | Current branch, active priorities, recent changes, known debt | Skills can't pre-populate "Current focus" lines in plans |

If your repo uses different names (e.g., `AGENTS.md` instead of `CLAUDE.md`, or `STATE.md` instead of `state.md`), update the file-name references in each SKILL.md to match.

A minimal `CLAUDE.md` to start with:

```markdown
# Project conventions

## Stack
<one-line summary of the stack>

## Absolute rules — never violate
1. **Never commit to main.** Use feature branches.
2. **Never skip verification gates.** Lint, typecheck, tests must pass before commit.
3. **Capture, don't carry.** Unrelated bugs noticed during a task get filed as idea files immediately, not held in conversation memory.
4. <project-specific rule>
5. <project-specific rule>

## Bug-fix protocol
1. Reproduce first
2. Root-cause to the right layer (don't patch symptoms)
3. Make the minimal change
4. Add a regression test that fails without the fix
5. Run the relevant test suite
6. Capture tangential discoveries as idea files
```

## Step 4 — Wire up the cross-model reviewer (optional but recommended)

The cross-model review pattern is one of the highest-leverage parts of this toolkit. To enable it:

1. Pick a reviewer model from a **different family** than the primary model running the skills. Examples: if your primary is Claude, use GPT-5 or Gemini as the reviewer. The cross-model value comes from different training and different blind spots — using two instances of the same model wastes the call.
2. In `PROJECT_CONFIG.md`, fill in the `## Cross-model reviewer` block with the model name, the API base URL, the env-var name for the API key, and a short snippet showing how to invoke it.
3. Make sure the API key is available where the skill expects it. Most projects store it in `.env`; the skills shell out to read it (`grep '^OPENAI_API_KEY=' .env | cut -d'=' -f2-` is the typical pattern). Adapt the parse to your env-var name.

If you can't set up cross-model review yet, every skill will fall back to a primary-model-only review loop. The skills will tell the user the cross-model step was skipped — they won't silently degrade.

## Step 5 — Try one end-to-end

Pick a small piece of work — a chore, a tiny refactor, a doc cleanup. Create an `idea.md`:

```bash
mkdir -p docs/02_product/planned_features/chore_my_first_pipeline_run/
cp docs/02_product/planned_features/feature_templates/idea-template.md \
   docs/02_product/planned_features/chore_my_first_pipeline_run/idea.md
# edit it to describe the chore
```

Run the orchestrator:

```
/pipeline docs/02_product/planned_features/chore_my_first_pipeline_run
```

The pipeline will:

1. Detect that only `idea.md` exists → stage is IDEA → next is SPEC.
2. Ask whether to proceed.
3. Invoke `/spec-gen`, run codebase verification, run cross-model review, gate major findings, write `feature_spec.md`.
4. Pause for your approval of the spec.
5. Invoke `/impl-plan-gen`, write `implementation_plan.md`.
6. Pause for your approval of the plan.
7. Invoke `/impl-execute`, run each story with verification gates, open a PR, watch CI, adjudicate review comments.
8. Move the folder to `implemented_features/<YYYY_MM_DD>_<slug>/` when complete.

If anything blocks (missing config, gate failure, ambiguous decision), the pipeline stops and tells you what to do.

## Common installation gotchas

- **Skills not detected by Claude Code.** Check that the path is exactly `.claude/skills/<name>/SKILL.md` (lowercase, no trailing slash issues, no `.txt`). Restart the Claude Code session after first install so it scans the folder.
- **`docs/02_product/planned_features/` doesn't match your IA.** That's fine — change the path in the relevant SKILL.md files. The folder location is not magic; it's just a convention. Make sure all skill references update together.
- **Reviewer model rejects requests.** The cross-model review prompts can be long. Check the model's context window and `max_completion_tokens` / `max_tokens` parameter naming — different APIs disagree. Adjust `PROJECT_CONFIG.md` to match.
- **`gh` CLI commands fail.** The toolkit assumes GitHub via `gh`. If you use GitLab/Bitbucket/Forgejo, replace `gh pr create` / `gh run watch` / `gh pr view` with the equivalents in each SKILL.md, or build a shim script and reference it.
- **Tests live somewhere unusual.** Update the test paths in each SKILL.md and in `PROJECT_CONFIG.md`. The skills are explicit about paths so search-and-replace works cleanly.

## Updating the toolkit

There is no auto-update mechanism. When you pull in a newer version:

1. Diff the new `SKILL.md` files against yours (you may have customized).
2. Merge intentional upstream improvements; keep your local customizations.
3. Re-check `PROJECT_CONFIG.md` for new placeholders.

Treat the skills as your team's source code — fork freely, edit deliberately.
