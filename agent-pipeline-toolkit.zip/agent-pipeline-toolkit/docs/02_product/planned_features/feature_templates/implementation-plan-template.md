# Implementation Plan — <Feature Name>

**Date:** <YYYY-MM-DD>
**Status:** <Draft | Ready for Execution | In Progress | Complete>
**Primary spec:** <link to feature_spec.md>
**Policy source(s):** <link to any policy docs>

---

## 0) Planning principles

- **Spec traceability first** — every story/task maps to FR IDs.
- **Phase gates are hard stops.**
- **Fail-loud tests** — assert explicit status, shape, errors.
- **Keep repository patterns consistent** — analogous code should look analogous.
- **Keep increments narrow enough to verify independently.**

## 1) Scope traceability (FR → epics/phases)

| FR ID | Epic/Phase | Notes |
|---|---|---|
| FR-1 | Epic <n> / Phase <n> | <note> |
| FR-2 | Epic <n> / Phase <n> | <note> |

**If any FRs are marked as out-of-scope for a future phase**, verify that a tracking artifact exists for the deferred work (`phase<N>_idea.md` in the feature directory — see `idea-template.md`). If not, create one before proceeding. Deferred FRs without a tracking file will be lost.

## 2) Delivery structure

Use one of:

- **Epic → Story → Tasks → DoD** (preferred for product-facing work)
- **Phase → Tasks → Checkpoint gate** (preferred for infra/migration-heavy work)

You may combine both, but every section must have measurable completion gates.

### Story-level detail requirements

Each story must include enough information for an engineer (or AI agent) to implement without interpretation gaps. The minimum required sections per story are:

1. **Outcome** — user or system behavior achieved.
2. **New files** — every file the story creates, with path and purpose.
3. **Modified files** — every file the story changes, with description of change.
4. **Endpoints** — method, path, request body, success response shape, and error codes (if story adds/changes API surface).
5. **Key interfaces** — function signatures with type hints for domain, service, and repo layers.
6. **Schemas** — request/response models (if API-facing).
7. **UI element inventory** — complete list of UI elements being created, moved, or removed (if story has frontend scope). See below.
8. **State dependency analysis** — state variables, callbacks, or data flows that cross component/story boundaries (if story modifies shared state). See below.
9. **Tasks** — specific implementation steps.
10. **Definition of Done** — observable completion gates with test layer references.

Stories that are purely documentation, refactor, or test-only may omit Endpoints/Schemas sections but must still include New/Modified files and Tasks/DoD.

### UI element inventory (for frontend stories)

For stories that create, move, or remove UI, include a complete inventory of every visual element. This prevents functionality loss during refactors.

For **creation/move** stories, list every card, form field, button, modal, alert, and interactive element the component must render. Include:
- Element type (card, input, select, checkbox, button, modal, alert, etc.)
- Label/title text
- Data source (which state variable or API call)
- User interactions (click handlers, submit behavior, validation)

For **removal** stories, list every element being removed and every state variable / callback being deleted.

### State dependency analysis (for refactors)

When a story removes or moves state, list every other component, callback, or rendering path that references that state.

Format:
```
State being removed: <variable name>
Referenced by:
  - <component/function> at <file:line> — action needed: <remove ref / refactor / replace>
```

### Conventions (project-specific — fill in from PROJECT_CONFIG.md)

Document the codebase conventions stories must follow. Pull these from `PROJECT_CONFIG.md` "Domain & convention notes." Examples:

```
- <e.g., All repo functions take `db: Session` as first arg; use `db.flush()` (caller commits)>
- <e.g., Services are async>
- <e.g., Domain layer is pure — no DB access, no side effects>
- <e.g., Routers return typed response models; errors use a structured detail envelope>
```

### AI Agent Execution Protocol (applies to every story)

If an AI agent will execute stories, the prescribed order is:

0. **Load context first** — read `<arch_doc>` and `<state_doc>` before starting the first story.
1. **Read scope** — verify story outcome + endpoints + interfaces + DoD.
2. **Implement backend first** — models → migration → repo → domain → service → router → schemas.
3. **Run backend tests** — minimum unit + integration + contract subset for touched endpoints.
4. **Implement frontend** (if story includes UI scope).
5. **Run E2E scope** for touched UX paths.
6. **Update docs/checklists** impacted by behavior changes in same PR.
7. **Verify migration round-trip** if schema changed.
8. **Attach evidence** in PR description: commands run, pass/fail, and files changed.
9. **After the final story**, update `<state_doc>` and `<arch_doc>`.

Story completion is invalid if any step above is skipped.

---

## Epic 1 — <Name>

### Story 1.1 — <Outcome title>
**Outcome:** <user/system outcome>

**New files**

List every file the story creates. Include the full path and a short purpose description.

**IMPORTANT for migration files:** Verify the actual migrations directory by running `ls` on the migrations path from `PROJECT_CONFIG.md` (`<migrations_dir>`). Check the current head revision number and use the next sequential number.

| File | Purpose |
|---|---|
| `<backend_root>/<module>/<file>` | <what this file provides> |
| `<frontend_root>/<route>/<file>` | <page/component purpose> |

**Modified files**

| File | Change |
|---|---|
| `<file>` | <description> |

**Endpoints** (if story adds or modifies API endpoints)

Define each endpoint with enough precision to implement and test without ambiguity.

| Method | Path | Request body | Success response | Error codes |
|---|---|---|---|---|
| `POST` | `/<resource>` | `{ field, field }` | `201` `{ id, field }` | `ERROR_CODE` (4xx) |
| `GET` | `/<resource>/{id}` | — | `200` `{ id, field, ... }` | `401`, `404` |

Use your project's endpoint prefix convention. Verify against existing routers.

**Key interfaces** (if story introduces domain/service/repo functions)

Provide function signatures with type hints. These are the contract that tests will validate.

```<language>
# <backend_root>/<module>/<file>
<function signature>   # brief purpose

# <repo_layer_path>
<function signature>

# <service_layer_path>
<function signature>
```

**Schemas** (if story adds API request/response models)

```<language>
class RequestModel:
    field: <type>
    optional_field: <type> | None = None

class ResponseModel:
    id: str
    field: <type>
```

**Tasks**
1. <implementation task — specific enough to execute without further interpretation>
2. <implementation task>
3. <validation task>

**Definition of Done (DoD)**
- <observable done condition>
- <test condition — specify which test layer>
- <operational/doc condition>

(Repeat stories and epics as needed.)

---

### Alternative: Phase → Tasks → Checkpoint gate

Use this structure for infra/migration-heavy work where sequential gating matters more than user-facing story outcomes.

#### Phase 1 — <Name>

**Tasks**
1. <implementation task>
2. <implementation task>
3. <validation task>

**Checkpoint gate** (hard stop — do not proceed until all pass)
- [ ] <measurable gate condition>
- [ ] <test/operational condition>
- [ ] <doc/review condition>

#### Phase 2 — <Name>
(Repeat as needed.)

---

## UI Guidance (required for frontend-facing work)

For features that add, move, or change UI, provide guidance that prevents ambiguity during implementation. **This section is especially important for AI agents that cannot visually verify their output.**

### Reference: current component structure

For each component being modified:
- **File path and total line count** — so the implementer knows the scale.
- **Section/card structure** — what sections exist, in what order, with line ranges.
- **State variables** — every state hook / signal / store with types.
- **Props** — the full interface definition.
- **Insertion points** — exact line numbers where new elements should go (e.g., "after line 286, before line 288").

### Analogous markup patterns (required for new UI sections)

When a new UI section should match an existing section's style, include the **actual markup** from the analogous section — not just a reference to it. Copy the JSX/template with CSS classes, inline styles, and component usage so the implementer has a copy-pasteable template.

**Why this matters:** Saying "follow the X pattern" is ambiguous. Showing the actual 20 lines of markup with concrete class names and component usage eliminates interpretation and ensures visual consistency.

Format each pattern as:
```<template_language>
{/* Pattern name — from <file>:<lines> */}
<ActualMarkup className="actual-class" style={{ actual: "styles" }}>
  {/* Include conditional logic, map() calls, and data bindings */}
</ActualMarkup>
```

### Layout and structure
- Describe the target layout pattern (flex, grid, stacked cards, tabs, etc.).
- Note responsive behavior (wrap, collapse, hide) if applicable.
- Reference existing CSS classes/patterns to reuse.

### Interaction behavior
- How do components on the same page communicate? (callback props, shared state, URL params)
- What happens when a user action on one tab affects another?
- Navigation within the page vs. between pages.

### Component composition
- Which components are extracted vs. inline?
- What props does each component accept? What callbacks does it expose?
- Are there any circular dependencies between parent and child state?

### Information architecture placement
- Where does this feature live in the navigation hierarchy?
- If adding a new tab or section, state what comes before and after it in the existing order.
- If moving elements between pages, list old location → new location with rationale.

### Tooltips and contextual help
- For each non-obvious UI element, specify the tooltip text, trigger mechanism, and placement.
- Use the tooltip inventory from the feature spec (§11) as the source of truth.
- Use the project's existing tooltip pattern.
- Include the actual JSX/markup for tooltips so the implementer doesn't need to guess the pattern.

### Visual consistency
- Name the existing patterns or components to match.
- Note any elements being ported between implementations with different styles.

### Legacy behavior parity (required when a story deletes or replaces a user-facing component >100 LOC, or migrates significant UI functionality between files)

Before deleting or replacing an existing component, enumerate every user-observable behavior it ships: client-side validations (min/max length, regex, required), loading states, disabled conditions, error messages, button-label changes tied to state, optimistic updates with rollback, confirmation dialogs, tooltips, focus management, keyboard shortcuts. Each behavior gets a verdict.

**Why this matters:** Deleting 1,000+ LOC of markup silently drops behaviors that tests don't assert. Typecheckers and happy-path renders do not catch a missing `minLength={20}` check, a button that re-fires while a request is in flight, or a confirmation dialog that quietly disappeared.

How to build the table:
1. Read the full deleted/replaced component top-to-bottom.
2. Grep it for: `onChange`, `onClick`, `onSubmit`, `onBlur`, `maxLength=`, `minLength=`, `pattern=`, `disabled=`, `aria-disabled`, `role="alert"`, `catch (`, `setError`, `setLoading`, `confirm(`.
3. For each match, add a row. No match should be unlisted.

Table format:

| # | Legacy behavior | Location in deleted component | Verdict | Preservation site / rationale |
|---|---|---|---|---|
| 1 | <e.g., NL description 20-char minimum before POST> | `<file>:<lines>` | Preserved | `<new_file>:<lines>` |
| 2 | <e.g., "Copy all keywords" quick action> | `<file>:<lines>` | Intentionally dropped | <cite spec section + date> |

Rules:
- The assigned story's **DoD must include a test assertion** (unit, integration, or E2E) for every row marked "Preserved." A "Preserved" row without a corresponding DoD test assertion is an incomplete story.
- "Intentionally dropped" rows must cite **a specific spec section, idea section, or product-decision reference with a date** — not "not required for MVP" without a source.
- If a behavior is being **weakened**, list it as a new row with verdict "Weakened" and the rationale.

Omit this subsection only when the feature does NOT delete or migrate any user-facing component >100 LOC. State explicitly: "No legacy behavior parity table — no user-facing component >100 LOC is being deleted or migrated in this plan."

### Client-side persistence (if applicable)

When a story uses client-side storage, explicitly state the persistence scope and mechanism:

- **`sessionStorage`** — cleared when the browser tab closes. Use for dismissals that should reappear on new visits.
- **`localStorage`** — persists indefinitely across sessions. Use for durable preferences.
- **In-memory state only** — cleared on navigation/remount. Use for transient UI state.

The DoD must match the mechanism: if the task says `sessionStorage`, the DoD must say "persists for the browser session" (not "persists across visits").

---

## 3) Testing workstream (required)

Plan testing explicitly by layer and map to stories.

### 3.1 Unit tests
- **Location:** `<unit test path>`
- **Scope:** domain logic, pure helpers, policy decisions, guardrails
- **Tasks:**
  - [ ] <unit test task>
- **DoD:** Critical branches covered and deterministic.

### 3.2 Integration tests
- **Location:** `<integration test path>`
- **Scope:** DB-backed workflows, transitions, migrations, idempotency
- **Tasks:**
  - [ ] <integration test task>
- **DoD:** Happy path + critical failure paths covered.

### 3.3 Contract tests
- **Location:** `<contract test path>`
- **Scope:** endpoint shape, status codes, machine-readable error codes
- **Tasks:**
  - [ ] <contract test task>
- **DoD:** No accepted endpoint without contract coverage.

### 3.4 E2E tests
- **Location:** `<e2e test path>`
- **Scope:** critical user/admin journeys, discoverability, role gating
- **Rule:** E2E tests must use real browser interactions. API-level setup is acceptable; assertions must verify browser-visible behavior — navigate pages, fill forms, click buttons, assert DOM elements. No request-level mocking of the SUT.
- **Tasks:**
  - [ ] <e2e test task>
- **DoD:** Stable profile pass for critical flows; tests use real browser interactions.

### 3.5 Existing test impact audit (required for refactors and UI changes)

Search all test files for references to pages, URLs, tab names, or behaviors that will change. List every file, the pattern found, the occurrence count, and the required action.

| Test file | Pattern | Count | Action |
|---|---|---|---|
| `<file>` | `<URL or assertion>` | <N> | `<update URL / update assertion / no change needed + why>` |

For files that need NO changes, explicitly state why they're safe.

### 3.6 Migration verification (if schema changes)
- [ ] Migration includes a `downgrade()` implementation (or your project's equivalent)
- [ ] `<migration_apply_command>` succeeds
- [ ] Round-trip verified: `<migration_roundtrip_command>`
- [ ] Any DB revision guard at API startup passes

### 3.7 CI gates
- [ ] `<unit_test_command>`
- [ ] `<integration_test_command>`
- [ ] `<contract_test_command>`
- [ ] `<e2e_test_command>` (if UI touched)

---

## 4) Documentation update workstream (required)

### 4.0 Core context files (required for every implementation plan)

These files are read at the start of every task and must stay accurate:

**`<state_doc>`** (e.g., `state.md`) — update if any of the following changed:
- [ ] Active branch changed
- [ ] New features were completed or priorities shifted
- [ ] New debt was introduced
- [ ] Migration head moved
- [ ] Current branch/execution context section needs updating

**`<arch_doc>`** (e.g., `architecture.md`) — update if any of the following changed:
- [ ] New services, layers, or components were added
- [ ] New data flows were introduced
- [ ] New integrations were wired in
- [ ] Design decisions were made or invariants changed
- [ ] Frontend page structure changed

**`<conventions_doc>`** (e.g., `CLAUDE.md`, `AGENTS.md`) — update if any of the following changed:
- [ ] New conventions, rules, or coding patterns were established
- [ ] New environment variables or build commands were added
- [ ] Feature status section needs updating

### 4.1 Architecture docs (`docs/01_architecture`)
- [ ] Update system boundaries and sequence/state diagrams
- [ ] Update API reference semantics where needed

### 4.2 Product docs (`docs/02_product`)
- [ ] Update user/admin behavior and UX flows
- [ ] Update role/action expectations

### 4.3 Runbooks (`docs/03_runbooks`)
- [ ] Add incident/remediation procedures
- [ ] Add rollback/replay/operational checks

### 4.4 Security docs (`docs/04_security`)
- [ ] Update threat model and control mapping
- [ ] Update secret/key handling guidance

### 4.5 Quality docs (`docs/05_quality`)
- [ ] Update testing strategy matrix
- [ ] Update release/quality checkpoints

**Documentation DoD**
- [ ] Core context files are consistent with shipped behavior.
- [ ] Docs across `docs/01-05` are consistent with shipped behavior and test contracts.
- [ ] Required runbooks are dry-run validated where practical.

---

## 5) Lean refactor workstream (required)

### 5.1 Refactor goals
- Eliminate duplication in critical code paths
- Centralize policy/authorization/error mapping logic
- Keep scope bounded — no speculative redesign

### 5.2 Planned refactor tasks
- [ ] Backend refactor: <task>
- [ ] Frontend refactor: <task>
- [ ] Remove dead/legacy branches after cutover

### 5.3 Refactor guardrails
- [ ] Behavioral parity proven by tests
- [ ] Lint/typecheck remain green
- [ ] No expansion of product scope
- [ ] Track discovered debt with owner + disposition

---

## 6) Dependencies, risks, and mitigations

### Dependencies

| Dependency | Needed by | Status | Risk if missing |
|---|---|---|---|
| <dependency> | <story> | <planned/implemented/blocked> | <impact> |

### Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| <risk> | <L/M/H> | <L/M/H> | <plan> |

### Failure mode catalog

| Failure mode | Trigger | Expected system behavior | Recovery |
|---|---|---|---|
| <failure description> | <what causes it> | <how the system should respond> | <auto/manual/alert> |

## 7) Sequencing and parallelization

### Suggested sequence
1. <epic/phase>
2. <epic/phase>
3. <epic/phase>

### Parallelization opportunities
- <what can run in parallel and why>

## 8) Rollout and cutover plan

- **Rollout stages:** <internal, limited, full>
- **Feature flag strategy:** <if used>
- **Migration/cutover steps:** <if needed>
- **Reconciliation/repair strategy:** <if external systems involved>

## 9) Execution tracker

### Current sprint
- [ ] <story/task>
- [ ] <story/task>

### Blocked items
- <item> — blocker: <reason> — owner: <name>

### Done this sprint
- [x] <completed item>

## 10) Story-by-Story Verification Gate (Agent Checklist)

Before marking any story complete, the executing engineer or agent must attach evidence for:

- [ ] Files created/modified match story scope (`New files` / `Modified files` tables)
- [ ] Endpoint contract implemented exactly as documented (method/path/body/status/error code)
- [ ] Key interfaces implemented with compatible signatures
- [ ] Required tests added/updated for all four layers where applicable
- [ ] Commands executed and passed:
    - [ ] `<unit_test_command>`
    - [ ] `<integration_test_command>` (or targeted subset with explanation)
    - [ ] `<contract_test_command>`
    - [ ] `<e2e_test_command>` (if UI touched)
- [ ] Migration round-trip evidence included if schema changed
- [ ] Related docs/checklists updated in same PR when behavior/contract changed

## 11) Plan consistency review (required before execution)

Before marking the plan as "Ready for Execution," perform a cross-reference review:

1. **Spec ↔ plan endpoint count** — count endpoints in spec §8.1 and verify the plan covers every one. Check that error codes in spec §8.5 appear in plan endpoint tables and contract test descriptions.

2. **Spec ↔ plan FR coverage** — verify every FR in the spec has a row in plan §1 traceability and is assigned to at least one story.

3. **Story internal consistency** — for each story, verify:
   - Endpoint table matches the schemas (field names, types).
   - DoD assertions reference the correct error codes and HTTP status codes.
   - New files are not claimed by multiple stories (no ownership conflict).
   - Modified files exist in the codebase.

4. **Test file count** — count test files listed across all stories; verify total matches the testing workstream (§3) inventory. **Every test file in §3 must be assigned to exactly one story's DoD.**

5. **Gate arithmetic** — verify epic/phase gate statements match actual endpoint/story counts.

6. **Open questions resolved** — confirm every open question from spec §19 is marked resolved with a decision log entry.

7. **Plan ↔ codebase verification** — verify key claims in the plan against the actual codebase:
   - State variable names and locations match.
   - Function names exist where claimed.
   - Line number references are approximately correct (within ~20 lines).
   - API endpoints used in the frontend match backend router definitions.
   - State dependencies between components are correctly identified.

8. **Infrastructure path verification** — verify file paths in "New files" tables match the actual project layout. Common mistakes: wrong migrations directory, wrong revision numbering, router registration assumptions.

9. **Frontend data plumbing verification** — for every prop a story adds to a component, verify the parent component actually has access to that data (or the plan includes fetching it).

10. **Persistence scope consistency** — for stories using client-side storage, verify task description and DoD agree on persistence scope.

11. **Enumerated value contract audit** — for every filter, sort key, status badge, role string, or other field the backend validates against a fixed allowlist:
    - Spec §8.4 must be present and cite concrete backend source files.
    - Frontend stories must enumerate wire values (not just labels) and cite source files.
    - Grep the cited source file(s) to confirm the exact allowlist.
    - Require a source-of-truth comment above each generated option array.

12. **Audit-event coverage audit** (if your project has audit-log infrastructure) — for every mutation the plan adds: verify spec audit-event matrix lists the mutation, the story includes an atomic audit log INSERT in the same transaction, metadata contains no credentials/tokens/PII, and a contract test asserts the audit row's metadata shape.

---

## 12) Definition of plan done

This implementation plan is execution-ready when:

- [ ] Every FR is mapped to stories/tasks/tests/docs updates.
- [ ] Every story includes New files, Modified files, Endpoints, Key interfaces, Tasks, and DoD.
- [ ] Test layers (unit/integration/contract/e2e) are explicitly scoped.
- [ ] Documentation updates across `docs/01-05` are planned and owned.
- [ ] Lean refactor scope and guardrails are explicit.
- [ ] Phase/epic gates are measurable and agreed by product + engineering.
- [ ] Story-by-Story Verification Gate is included.
- [ ] Plan consistency review (§11) has been performed with no unresolved findings.
