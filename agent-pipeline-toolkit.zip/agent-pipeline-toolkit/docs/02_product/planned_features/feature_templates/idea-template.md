# <Feature or Phase Name>

**Date:** <YYYY-MM-DD>
**Status:** Idea — <origin context, e.g., "new capability proposal" / "deferred from Phase 1 implementation" / "identified during planning">
**Origin:** <Pointer to source — e.g., "Deferred Phase 2 work from `feature_spec.md` (lines N-M)" / "User request during sprint planning" / "Customer feedback ticket #1234">
**Depends on:** <What must be merged/deployed first, or "None">

## Problem

<What gap or need does this idea address? 2-4 sentences. If deferred from a prior phase, explain what remains unsolved after the implemented phase ships.>

## Proposed capabilities

<List the capabilities at a level of detail sufficient to generate a feature spec later. For deferred spec phases, include the FR numbers and descriptions from the original spec.>

### <Capability 1 name>

- <Key behavior or requirement>
- <Key behavior or requirement>

### <Capability 2 name>

- <Key behavior or requirement>
- <Key behavior or requirement>

## Scope signals

<Brief notes on which layers/systems are likely affected. Not a full spec — just enough to estimate complexity.>

- **Backend:** <impact hints, or `N/A`>
- **Frontend:** <impact hints, or `N/A`>
- **Migration:** <expected schema changes, or `none expected`>
- **Config:** <new settings, env vars, feature flags>
- **External services:** <any third-party integrations affected>
- **Audit events:** <new event types this idea introduces, OR `N/A` if no state mutations or if audit infrastructure doesn't exist yet>

## Why <deferred / not yet prioritized / now>

<The rationale for this idea's timing. If deferred, copy the reasoning from the spec's phase boundary description. If now, state the trigger (customer asked, blocker for another feature, etc.). This helps future planners decide when to pick it up.>

## Relationship to other work

<Optional. Note if this idea supersedes, extends, or conflicts with other planned features. Reference sibling folders by name.>

- Coordinates with: `<sibling_folder>` — <why>
- Supersedes: `<prior_folder>` — <why>
- Conflicts with: `<other_folder>` — <how to reconcile>

## Open forks (for /spec-gen to resolve)

<Optional. Any "Option A vs Option B" decisions that need to be made during spec authoring. Each fork should have a recommended default — don't start the spec from zero.>

- **<Fork name>:** Option A (<short description>) vs. Option B (<short description>). Recommended default: <A or B>. Why: <one-line rationale>.
