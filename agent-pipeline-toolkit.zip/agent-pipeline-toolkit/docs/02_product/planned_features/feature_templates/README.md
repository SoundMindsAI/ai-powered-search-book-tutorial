# Feature Templates

Templates for the idea → spec → plan → implement pipeline. Each new feature folder under `<planned_features_root>` gets one (or more) of these files copied in and filled out.

1. [`idea-template.md`](idea-template.md) — lightweight capture for new ideas and deferred / exploratory work
2. [`feature-spec-template.md`](feature-spec-template.md) — full feature specification (the contract between product and engineering)
3. [`implementation-plan-template.md`](implementation-plan-template.md) — story-by-story plan derived from an approved spec

## How to use

1. Copy the relevant template into your target feature folder under `<planned_features_root>`.
2. Replace every `<placeholder>`.
3. Reference your project's canonical architecture docs for technical decisions (stack, conventions, data model). **Specs should cite arch docs by section, not duplicate them.** When the arch doc changes, the spec stays correct.
4. Keep section order unless there's a strong reason to deviate — skills look for the canonical headings.
5. Do **not** delete traceability, test strategy, or documentation-update sections from the spec/plan. They are load-bearing for the verification gates downstream.

## Folder naming convention

New folders under `<planned_features_root>` use a single-axis **work-type prefix**, mirroring Conventional Commits prefixes:

| Prefix | Use for | Example |
|---|---|---|
| `feat_` | New user-facing capability or behavior | `feat_user_onboarding/` |
| `bug_` | Defect fix with user-visible impact | `bug_export_csv_dates_off_by_one/` |
| `chore_` | Refactor, rename, dead-code removal, tech debt — no user-visible behavior change | `chore_rename_widget_to_card/` |
| `infra_` | Deployment, CI, hosting, environment, dependency upgrades | `infra_postgres_15_upgrade/` |
| `epic_` | Multi-phase bundle containing ≥2 dependent child feature folders | `epic_observability/phase_01_metrics/` |

**Rules:**

- **One prefix per folder.** If work spans types (refactor that enables a new feature), pick the one the **user** sees first — usually `feat_`.
- **Domain is conveyed by the name**, not by a second prefix. `feat_user_onboarding/` is obviously about onboarding; `feat_users_onboarding_management_v1/` is noise.
- **Epic children use `phase_NN_` numbering** for dependency order — `phase_01_xxx`, `phase_02_yyy`.
- **Keep the prefix short (≤6 chars)** so the descriptive tail gets the character budget.
- **Folder names should telegraph why the feature exists**, not just what file it touches:
  - Vague: `feat_report_freshness`. Better: `feat_report_30day_refresh` (says what ships).
  - Aspirational: `epic_auto_apply_changes`. Better after scope cut: `feat_changes_pr_open_and_merge` (says what the first version actually does).

## File anatomy inside a feature folder

A mature feature folder looks like this:

```
<planned_features_root>/<prefix>_<slug>/
├── idea.md                    ← always present; captures the why + the rough what
├── feature_spec.md            ← present after /spec-gen
├── implementation_plan.md     ← present after /impl-plan-gen
├── pipeline_status.md         ← present after /spec-gen; tracks stage completion
├── bug_fix.md                 ← only for /bug-fix flow; replaces spec+plan for medium bugs
├── phase2_idea.md             ← present if the spec/plan defines deferred Phase 2 work
└── phase3_idea.md             ← same for Phase 3, etc.
```

When the feature ships, the **entire folder** moves to `<implemented_features_root>/<YYYY_MM_DD>_<short_name>/`. The archive is self-contained — anyone reading the implemented archive can see how the idea evolved into a spec, then a plan, then code.

## When to write what

| Situation | Start with |
|---|---|
| New user-facing capability with non-trivial design surface | `idea.md` (then `/pipeline` to advance) |
| Tracking deferred work from a finished feature | `idea.md` named `phase2_idea.md` / `phase3_idea.md` in the original folder |
| Medium-sized bug (~50–500 LOC, has design surface) | `idea.md` first, then `/bug-fix` produces `bug_fix.md` (not a full spec) |
| Tiny bug fix (one-line, no design surface) | Just edit and run `/impl-execute --ad-hoc`. No idea file needed. |
| Multi-phase initiative spanning multiple dependent features | `epic_<name>/` folder containing `phase_NN_xxx/` child folders, each with its own idea.md |
