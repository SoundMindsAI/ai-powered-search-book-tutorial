# PROJECT_CONFIG.md

This is the **single source of truth** for stack-specific details the skills need. Each skill references this file via `<placeholder>` substitutions. Fill in every block that applies to your project. Skip blocks for capabilities you don't have yet — the skills degrade gracefully.

Keep this file at the **repository root** so every skill can find it with a relative path.

---

## Repository layout

> Where the code lives. Skills use these to scope verification reads.

| Placeholder | Value | Notes |
|---|---|---|
| `<repo_root>` | `<absolute or relative path>` | Default: current working directory. |
| `<backend_root>` | `<e.g., backend/, server/, api/, src/server/>` | Where backend code lives. Use `N/A` for frontend-only projects. |
| `<frontend_root>` | `<e.g., web/, ui/, frontend/, apps/web/>` | Where frontend code lives. Use `N/A` for backend-only projects. |
| `<shared_root>` | `<e.g., shared/, common/, packages/>` | Cross-cutting code (types, utils). Optional. |
| `<docs_root>` | `<e.g., docs/>` | Where documentation lives. |
| `<planned_features_root>` | `<e.g., docs/02_product/planned_features/>` | Where idea.md / feature_spec.md / implementation_plan.md live before merge. |
| `<implemented_features_root>` | `<e.g., docs/00_overview/implemented_features/>` | Where feature folders move after merge. |

## Build & test commands

> Every skill calls these. Use the **exact** command line you'd type in a shell.

| Placeholder | Command | When invoked |
|---|---|---|
| `<lint_command>` | `<e.g., make lint, npm run lint, cargo clippy, ruff check .>` | After every code change, before commit |
| `<format_command>` | `<e.g., make fmt, prettier --write, gofmt -w, ruff format>` | Before commit; idempotent expected |
| `<format_check_command>` | `<e.g., ruff format --check ., prettier --check>` | CI-parity check — must agree with CI |
| `<typecheck_command>` | `<e.g., make typecheck, npm run typecheck, tsc --noEmit, mypy>` | After every code change |
| `<unit_test_command>` | `<e.g., make test-unit, npm test, pytest backend/tests/unit/, go test ./...>` | After every story |
| `<integration_test_command>` | `<e.g., make test-integration, pytest backend/tests/integration/>` | When story touches DB/services/endpoints |
| `<contract_test_command>` | `<e.g., make test-contract, pytest backend/tests/contract/>` | When story adds/modifies API |
| `<e2e_test_command>` | `<e.g., npx playwright test, cypress run>` | When story changes UI behavior |
| `<frontend_build_command>` | `<e.g., npx next build, npm run build>` | After UI changes — catches SSR/import issues |
| `<full_test_suite_command>` | `<e.g., make test, npm test>` | At phase gates |

## Migration tooling

> Used by stories that change the data model. Use `N/A` for the entire block if your project has no DB.

| Placeholder | Value | Notes |
|---|---|---|
| `<migration_tool>` | `<e.g., Alembic, Prisma, Knex, Flyway, Liquibase, sqlx>` | Name |
| `<migrations_dir>` | `<e.g., backend/alembic/versions/, prisma/migrations/>` | Where migration files live |
| `<migration_create_command>` | `<e.g., alembic revision -m, prisma migrate dev --name>` | Make a new migration |
| `<migration_apply_command>` | `<e.g., alembic upgrade head, prisma migrate deploy>` | Apply pending migrations |
| `<migration_rollback_command>` | `<e.g., alembic downgrade -1>` | Roll back the last migration |
| `<migration_roundtrip_command>` | `<e.g., alembic downgrade -1 && alembic upgrade head>` | Required after every new migration |
| Downgrade required? | `<yes / no — usually yes for safety>` | Most teams require reversible migrations |
| Idempotency guards required? | `<yes / no>` | If yes, every `add_column` / `drop_column` / `create_table` should be wrapped to be re-runnable |

## Branch & PR tooling

| Placeholder | Value | Notes |
|---|---|---|
| `<vcs_host>` | `<e.g., GitHub, GitLab, Bitbucket, Gitea>` | Affects which CLI is used |
| `<pr_cli>` | `<e.g., gh, glab, tea>` | The host's PR CLI |
| `<default_branch>` | `<e.g., main, master, trunk>` | Branch new feature branches fork from and PRs target |
| `<feature_branch_prefix>` | `<e.g., feature/, feat/, dev/>` | Prefix the skills use when auto-naming branches |
| `<commit_style>` | `<e.g., Conventional Commits, Gitmoji, freeform>` | Commit message convention |
| `<pr_open_command>` | `<e.g., gh pr create --title "..." --body "...">` | How to open a PR from CLI |
| `<pr_view_command>` | `<e.g., gh pr view <number>>` | How to read a PR's state and review threads |
| `<pr_comments_endpoint>` | `<e.g., gh api repos/<org>/<repo>/pulls/<num>/comments>` | How to read inline review comments |
| `<ci_status_command>` | `<e.g., gh run list --branch=<branch>, gh run watch <id>>` | Watch / inspect CI runs |

## Cross-model reviewer

> A different-family model that audits artifacts written by the primary model. This is the single highest-quality lever in the toolkit. Skip the block if you can't wire one in, and the skills will use primary-model-only convergence.

| Placeholder | Value | Notes |
|---|---|---|
| `<secondary_model>` | `<e.g., gpt-5, gemini-2.0-pro, llama-3.3-70b, o1>` | Exact model ID for API calls |
| `<secondary_model_family>` | `<e.g., OpenAI, Google, Meta, local>` | For the user-facing "reviewed by" label |
| `<secondary_api_base>` | `<e.g., https://api.openai.com/v1, https://generativelanguage.googleapis.com/v1>` | API base URL |
| `<secondary_api_key_envvar>` | `<e.g., OPENAI_API_KEY, GEMINI_API_KEY, ANTHROPIC_API_KEY>` | Env var that holds the key |
| `<secondary_api_key_source>` | `<e.g., .env file via grep, OS env, secrets manager>` | Where the key lives |
| `<secondary_api_token_param>` | `<e.g., max_completion_tokens vs. max_tokens>` | Models disagree on this; pin it |
| Max convergence cycles | `3` | Recommended. After N cycles of "X says it's wrong" / "Y says no it's right" without movement, escalate. |
| Sample API call | `<paste a working curl or Python snippet for one call>` | So the agent has a template to imitate |

**Cross-model review protocol** (reference — the skills implement this):

1. Primary model writes the artifact (spec, plan, code review, etc.).
2. Primary sends the artifact + a structured prompt with focus areas to the secondary.
3. Secondary returns findings as structured JSON: `{severity, location, claim, evidence}`.
4. Primary adjudicates each finding: **accept** (cite the evidence, stage a correction) / **reject** (cite counter-evidence from code — "I disagree" without a file:line citation is not allowed) / **escalate** (present to user).
5. If any accepted correction changed a *major* element, re-send the corrected artifact for another cycle. Cap at 3 cycles.
6. On cycle 2+, include a "previously rejected findings" block in the prompt so the secondary doesn't re-raise dismissed claims without new information.

## Source-of-truth grounding rules

> The skills enforce that every option list, enum, or filter value the frontend sends back to the backend cites a concrete source-of-truth file. Fill in the patterns your project uses so the skills know what to grep for.

| Type | Project pattern | Example |
|---|---|---|
| Backend enum | `<e.g., Python Literal[...], Pydantic Field(pattern=...), TS string union, Go const block, DB CHECK constraint>` | `<paste a real example>` |
| Source-of-truth comment | `<e.g., // Values must match <backend_path>:<symbol>>` | Required above every frontend option array |

## Test layer locations

| Test layer | Path | Pattern file (canonical example) |
|---|---|---|
| Unit | `<e.g., backend/tests/unit/>` | `<e.g., test_quota_enforcement.py>` |
| Integration | `<e.g., backend/tests/integration/>` | `<e.g., test_billing_integration.py>` |
| Contract | `<e.g., backend/tests/contract/>` | `<e.g., test_contracts.py>` |
| E2E | `<e.g., web/tests/e2e/>` | `<e.g., signup_flow.spec.ts>` |

## Operator paths (commands tenants/operators run)

> When a story adds a new Makefile target, install script, Docker Compose service, or similar, the skill runs the actual command end-to-end before declaring the story complete. List the operator commands you have so the skill knows what to exercise.

| Surface | Verification command | Expected side effect |
|---|---|---|
| `<e.g., make up>` | `<docker compose ps shows all services healthy>` | All containers up, healthchecks green |
| `<e.g., make migrate>` | `<new file lands in migrations dir with expected revision id format>` | Migration file created |
| `<e.g., scripts/install.sh>` | `<run from clean state; re-run for idempotency>` | Bootstrap completes; second run is no-op |

## Domain & convention notes

> Project-specific patterns the agent needs to know about. Be concrete. Examples:

- `<e.g., All repo functions take db: Session as first arg; use db.flush() (caller commits)>`
- `<e.g., Services are async; create job_run at start where applicable>`
- `<e.g., Domain layer is pure — no DB access, no side effects>`
- `<e.g., Routers return typed Pydantic response models; errors use HTTPException with structured detail>`
- `<e.g., All __init__.py exports updated via __all__>`
- `<e.g., Frontend uses Tailwind utility classes only; no inline styles>`
- `<e.g., Date columns are timestamptz; never local time>`
- `<e.g., All HTTP endpoints prefixed with /api/v1/; operator/webhook endpoints unprefixed>`

## Maturity profile

> Optional — helps the skills calibrate strictness. Set the release/maturity stage of the project.

| Field | Value | Effect on skills |
|---|---|---|
| Maturity | `<MVP / GA / mature>` | MVP skips audit_log/RBAC enforcement; mature requires them |
| Has auth surface? | `<yes / no>` | Affects auth-related checks in spec-gen and impl-plan-gen |
| Has multi-tenant model? | `<yes / no>` | Affects tenant_id scoping checks |
| Has audit log? | `<yes / no>` | Skip audit-event enforcement when no |
| Has tenant-facing UI? | `<yes / no>` | Activates guide-gen; otherwise it's dormant |

## Feature folder taxonomy

> The folder prefixes the skills expect under `<planned_features_root>`. Defaults match Conventional Commits. Change if your team uses different prefixes.

| Prefix | Meaning |
|---|---|
| `feat_` | New user-facing capability |
| `bug_` | Defect fix with user-visible impact |
| `chore_` | Refactor, rename, dead-code removal — no behavior change |
| `infra_` | Deployment, CI, dependencies, environment |
| `epic_` | Multi-phase bundle containing dependent child folders |

## "Done" definition

> When does a feature move from `planned_features/` to `implemented_features/`?

The default trigger is: PR merged + CI green + every `phase*_idea.md` (if any) consciously addressed (split into a new planned feature or explicitly accepted as deferred-with-tracking).

If your team uses a different trigger (staging deploy verified, manual QA sign-off, etc.), document it here so the skills know when to move the folder.

---

## How the skills use this file

When a skill encounters a `<placeholder>` in its own instructions, it reads `PROJECT_CONFIG.md` and substitutes the configured value. If the placeholder is missing or empty, the skill:

1. Asks the user for the value inline, OR
2. Falls back to a reasonable default (and tells the user), OR
3. Aborts the step if the value is load-bearing (e.g., no test command means no verification gate).

You can always add new placeholders. Conventions:
- Use `<snake_case_placeholder>` in skills.
- Document the placeholder here with its expected value type.
- Reference the placeholder consistently across all skills that use it.
